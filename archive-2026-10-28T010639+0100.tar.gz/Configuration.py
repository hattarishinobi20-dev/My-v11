
# DisableNagle: reduce delay and improve performance between client and server BUT require more power #

settings = {
    "DisableNagle": True,
    "PrintEnabled": True,
    "UseContentUpdater": False,
    "Proxy": False,
    "DumpPacket": True,
    "Blacklist": [],
    "DumpMajor": 11
}