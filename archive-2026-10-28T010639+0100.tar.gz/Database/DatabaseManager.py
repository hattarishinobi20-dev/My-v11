import sqlite3
import json
import os
import threading
import time
import random
from Files.CsvLogic.Locations import Locations
import datetime 
from datetime import datetime, timedelta, timezone
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
class DataBase:
    _initialized_databases = set()
    _initialization_lock = threading.Lock()
    _account_creation_lock = threading.Lock()

    def __init__(self, player):
        self.player = player
        database_path = os.path.abspath('database.db')
        self.connection = sqlite3.connect(database_path, timeout=30)
        self.cursor = self.connection.cursor()
        with DataBase._initialization_lock:
            if database_path not in DataBase._initialized_databases:
                self._initialize_tables()
                DataBase._initialized_databases.add(database_path)

    def _initialize_tables(self):
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS Matchmake (
            slot INTEGER PRIMARY KEY,
            data TEXT
        )
        ''')
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS PlayerOffers (
            PlayerToken TEXT PRIMARY KEY,
            Offers TEXT NOT NULL
        )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Players (
                token TEXT PRIMARY KEY,
                data TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Gamerooms (
                room_id INTEGER PRIMARY KEY,
                data TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Clubs (
                club_id INTEGER PRIMARY KEY,
                data TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS ClubChats (
                club_id INTEGER PRIMARY KEY,
                data TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS GameroomChats (
                room_id INTEGER PRIMARY KEY,
                data TEXT
            )
        ''')
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS Events (
            state INTEGER PRIMARY KEY,
            data TEXT
        )
        ''')
        self.connection.commit()
        self._seed_default_events()

    def _seed_default_events(self):
        try:
            self.cursor.execute("SELECT COUNT(*) FROM Events WHERE state = 1")
            if self.cursor.fetchone()[0] > 0:
                return
            stamp = int((datetime.now() + timedelta(days=1)).replace(hour=10, minute=0, second=0, microsecond=0).timestamp())
            default_maps = [7, 16, 23, 1, 38, 25]
            data = {"info": {"events": {str(i): {"ID": m, "Status": 2, "TimeStamp": stamp,
                                                 "Modifier": {"0": 0}, "Tokens": 10 if i < 5 else 12}
                                         for i, m in enumerate(default_maps)}}}
            for state in (1, 2):
                self.cursor.execute("INSERT OR IGNORE INTO Events (state, data) VALUES (?, ?)",
                                    (state, json.dumps(data)))
            self.connection.commit()
        except Exception:
            pass

    def loadAccount(self):
        connection_ip = getattr(self.player, "last_ip", "")
        self.cursor.execute("SELECT data FROM Players WHERE token = ?", (self.player.token,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            for key, value in playerData.items():
                setattr(self.player, key, value)
            if "tokens_doubler" in playerData:
                self.player.tokensdoubler = playerData["tokens_doubler"]
            if connection_ip:
                self.player.last_ip = connection_ip
                if playerData.get("last_ip") != connection_ip:
                    self.replaceValue("last_ip", connection_ip)
            if getattr(self.player, "player_experience", 0) < 9999:
                self.player.player_experience = 9999
                self.replaceValue("player_experience", 9999)
    def _daily_tokens_cap(self):
        try:
            return int(self.player.settings.get("DailyTokens", 400))
        except Exception:
            return 400

    def _tokens_refill_seconds(self):
        try:
            return int(self.player.settings.get("TokensRefillHours", 17)) * 3600
        except Exception:
            return 17 * 3600

    def refresh_tokens(self):
        now = int(time.time())
        cap = self._daily_tokens_cap()
        available = getattr(self.player, "available_tokens", None)
        if available is None:
            available = cap
        refill = getattr(self.player, "tokens_refill_time", 0) or 0
        changed = False
        if refill and now >= refill:
            available = cap
            refill = 0
            changed = True
        if available > cap:
            available = cap
            changed = True
        elif available < 0:
            available = 0
            changed = True
        if available == 0 and not refill:
            refill = now + self._tokens_refill_seconds()
            changed = True
        self.player.available_tokens = available
        self.player.availabletokens = available
        self.player.tokens_refill_time = refill
        if changed:
            self.replaceValue("available_tokens", available)
            self.replaceValue("tokens_refill_time", refill)
        return available

    def consume_tokens(self, amount):
        available = self.refresh_tokens()
        granted = max(0, min(int(amount), available))
        if granted:
            available -= granted
            self.player.available_tokens = available
            self.player.availabletokens = available
            self.replaceValue("available_tokens", available)
            if available == 0:
                refill = int(time.time()) + self._tokens_refill_seconds()
                self.player.tokens_refill_time = refill
                self.replaceValue("tokens_refill_time", refill)
        return granted

    FREE_MEGA_CLAIMED_TIMER = 4102444800

    def _free_mega_claimed(self, player_token):
        if getattr(self.player, "free_mega_claimed", 0):
            return True
        try:
            row = self.cursor.execute("SELECT data FROM Players WHERE token = ?", (player_token,)).fetchone()
            if row:
                return bool(json.loads(row[0]).get("free_mega_claimed", 0))
        except Exception:
            pass
        return False

    def _mark_free_mega_claimed(self):
        if not getattr(self.player, "free_mega_claimed", 0):
            self.player.free_mega_claimed = 1
            try:
                self.replaceValue("free_mega_claimed", 1)
            except Exception:
                pass

    @staticmethod
    def visible_offer_keys(offers):
        info = (offers or {}).get("info", {}) if isinstance(offers, dict) else {}
        def _int_key(key):
            try:
                return int(key)
            except (TypeError, ValueError):
                return 999999999
        keys = sorted(info.keys(), key=_int_key)
        mega = info.get("0") or {}
        if mega.get("OfferID") == 10 and mega.get("IsOfferPurchased") == 1:
            keys = [key for key in keys if key != "0"]
        return keys

    def load_offers(self, player_token):
        query = "SELECT Offers FROM PlayerOffers WHERE PlayerToken = ?"
        self.cursor.execute(query, (player_token,))
        result = self.cursor.fetchone()
        if result:
            data = json.loads(result[0])
            changed = self._remove_skin_offers(data)
            info = data.get("info", {})
            expected = [(10, 1, [0, 0], 1, 2, 0), (0, 1, [0, 0], 1, 0, 0)]
            valid = len(info) >= 2
            if valid:
                for index, expected_offer in enumerate(expected):
                    offer = info.get(str(index)) or {}
                    if offer.get("OfferID") != expected_offer[0] or offer.get("Amount") != expected_offer[1] or offer.get("Target") != expected_offer[2] or offer.get("Value") != expected_offer[3] or offer.get("Currency") != expected_offer[4] or offer.get("Price") != expected_offer[5] or "Items" in offer:
                        valid = False
                        break
            if not valid:
                self.initialize_player_offers(player_token)
                self.cursor.execute(query, (player_token,))
                result = self.cursor.fetchone()
                return json.loads(result[0]) if result else {}
            mega_offer = info.get("0") or {}
            if mega_offer.get("IsOfferPurchased") == 1:
                self._mark_free_mega_claimed()
            elif self._free_mega_claimed(player_token) and mega_offer.get("OfferID") == 10:
                mega_offer["IsOfferPurchased"] = 1
                mega_offer["IsOfferSeen"] = 1
                mega_offer["Timer"] = self.FREE_MEGA_CLAIMED_TIMER
                changed = True
            if changed:
                self.save_offers(player_token, data)
            return data#.get("info", {})
        return {}

    MAX_POWER_POINTS_OFFERS = 5
    POWER_POINTS_MIN = 16
    POWER_POINTS_MAX = 100
    GOLD_PER_POWER_POINT = 2
    FREE_POWER_POINTS_CHANCE = 20
    MAX_POWER_LEVEL = 8
    MAX_POWER_POINTS = 1410

    def _load_special_offer_config(self):
        self.special_offer = json.load(open('special_offer.json'))
        self.hasSpecialOffer = self.special_offer["isEnabled"]

    def _daily_offer_timer(self):
        end = (datetime.now(timezone.utc) + timedelta(days=1)).replace(
            hour=8, minute=0, second=0, microsecond=0)
        return int(end.timestamp())

    def _power_point_candidates(self, exclude=None):
        exclude = exclude or set()
        candidates = []
        for key, data in self.player.unlocked_brawlers.items():
            try:
                brawler_id = int(key)
            except (TypeError, ValueError):
                continue
            if brawler_id in exclude:
                continue
            if data.get("PowerLevel", 0) >= self.MAX_POWER_LEVEL:
                continue
            if data.get("PowerPoints", 0) >= self.MAX_POWER_POINTS:
                continue
            candidates.append(brawler_id)
        return candidates

    def _make_power_points_offer(self, brawler_id, timer):
        amount = random.randint(self.POWER_POINTS_MIN, self.POWER_POINTS_MAX)
        price = 0 if random.randint(1, 100) <= self.FREE_POWER_POINTS_CHANCE else amount * self.GOLD_PER_POWER_POINT
        return {
            "OfferID": 8,
            "Target": [16, brawler_id],
            "Value": 0,
            "Amount": amount,
            "Currency": 1,
            "Price": price,
            "Timer": timer,
            "IsOfferSeen": 0,
            "IsOfferPurchased": 0
        }

    def _make_mega_box_offer(self, timer):
        self._load_special_offer_config()
        offer = dict(self.special_offer)
        special_timer = offer.get("Timer", 0)
        if not isinstance(special_timer, (int, float)) or special_timer <= int(time.time()):
            special_timer = int(time.time()) + 7 * 24 * 60 * 60
        offer["Timer"] = int(special_timer)
        return offer

    def _make_free_box_offer(self, timer):
        return {
            "OfferID": 0,
            "Target": [0, 0],
            "Value": 1,
            "Amount": 1,
            "Currency": 0,
            "Price": 0,
            "Timer": timer,
            "IsOfferSeen": 0,
            "IsOfferPurchased": 0
        }

    def _remove_skin_offers(self, offers):
        changed = False
        for key, offer in list(offers.get("info", {}).items()):
            if offer.get("OfferID") != 4:
                continue
            timer = offer.get("Timer", self._daily_offer_timer())
            used = set()
            for other_key, info in offers["info"].items():
                target = info.get("Target")
                if other_key != key and info.get("OfferID") == 8 and isinstance(target, list) and len(target) > 1:
                    used.add(target[1])
            candidates = self._power_point_candidates(exclude=used)
            if candidates:
                new_offer = self._make_power_points_offer(random.choice(candidates), timer)
            else:
                new_offer = self._make_free_box_offer(timer)
            new_offer["IsOfferPurchased"] = offer.get("IsOfferPurchased", 0)
            offers["info"][key] = new_offer
            changed = True
        return changed

    def initialize_player_offers(self, player_token):
        timer = self._daily_offer_timer()
        offers = {"info": {}}
        mega_offer = self._make_mega_box_offer(timer)
        if self._free_mega_claimed(player_token):
            mega_offer["IsOfferPurchased"] = 1
            mega_offer["IsOfferSeen"] = 1
            mega_offer["Timer"] = self.FREE_MEGA_CLAIMED_TIMER
        offers["info"][str(0)] = mega_offer
        offers["info"][str(1)] = self._make_free_box_offer(timer)
        candidates = self._power_point_candidates()
        random.shuffle(candidates)
        slot = 2
        for brawler_id in candidates[:self.MAX_POWER_POINTS_OFFERS]:
            offers["info"][str(slot)] = self._make_power_points_offer(brawler_id, timer)
            slot += 1
        self.save_offers(player_token, offers)

    def reroll_offer(self, player_token, i):
        timer = self._daily_offer_timer()
        offers = self.load_offers(self.player.token)
        if not offers or "info" not in offers:
            self.initialize_player_offers(player_token)
            return
        if i == 0 and self._free_mega_claimed(player_token):
            mega_offer = offers["info"].get("0") or self._make_mega_box_offer(timer)
            mega_offer["IsOfferPurchased"] = 1
            mega_offer["IsOfferSeen"] = 1
            mega_offer["Timer"] = self.FREE_MEGA_CLAIMED_TIMER
            offers["info"]["0"] = mega_offer
            self.save_offers(player_token, offers)
            return
        if i == 0:
            offer = self._make_mega_box_offer(timer)
        elif i == 1:
            offer = self._make_free_box_offer(timer)
        else:
            used = set()
            for key, info in offers["info"].items():
                if key == str(i):
                    continue
                target = info.get("Target")
                if info.get("OfferID") == 8 and isinstance(target, list) and len(target) > 1:
                    used.add(target[1])
            candidates = self._power_point_candidates(exclude=used)
            if candidates:
                offer = self._make_power_points_offer(random.choice(candidates), timer)
            elif str(i) in offers["info"]:
                offer = dict(offers["info"][str(i)])
                offer["Timer"] = timer
                offer["IsOfferSeen"] = 0
                offer["IsOfferPurchased"] = 0
            else:
                self.save_offers(player_token, offers)
                return
        offers["info"][str(i)] = offer
        self.save_offers(player_token, offers)

    def save_offers(self, player_token, offers):
        query = "INSERT OR REPLACE INTO PlayerOffers (PlayerToken, Offers) VALUES (?, ?)"
        offers_json = json.dumps(offers)
        self.cursor.execute(query, (player_token, offers_json))
        self.connection.commit()
 
    def getPlayerId(self):
        self.cursor.execute("SELECT data FROM Players")
        max_id = 0
        for row in self.cursor.fetchall():
            try:
                max_id = max(max_id, int(json.loads(row[0]).get("low_id", 0)))
            except Exception:
                continue
        self.player.low_id = max_id + 1

    def createAccount(self):
        with DataBase._account_creation_lock:
            return self._createAccount()

    def _createAccount(self):
        self.cursor.execute("SELECT COUNT(*) FROM Players WHERE token = ?", (self.player.token,))
        count = self.cursor.fetchone()[0]
        if count > 0:
            raise ValueError(f"Account with token {self.player.token} already exists.")
        self.cursor.execute("SELECT data FROM Players")
        existing_low_ids = set()
        max_low_id = 0
        for row in self.cursor.fetchall():
            try:
                existing_low_id = int(json.loads(row[0]).get("low_id", 0))
            except Exception:
                continue
            existing_low_ids.add(existing_low_id)
            max_low_id = max(max_low_id, existing_low_id)
        try:
            requested_low_id = int(self.player.low_id)
        except (TypeError, ValueError):
            requested_low_id = 0
        if requested_low_id <= 0 or requested_low_id in existing_low_ids:
            self.player.low_id = max_low_id + 1
        data = {
            "name": self.player.name,
            "low_id": self.player.low_id,
            "club_id": 0,
            "club_role": 0,
            "is_fb_linked": 0,
            "facebook_id": self.player.FacebookID,
            "player_experience": self.player.player_experience,
            "solo_wins": self.player.solo_wins,
            "duo_wins": self.player.duo_wins,
            "three_vs_three_wins": self.player.ThreeVSThree_wins,
            "gems": self.player.gems,
            "gold": self.player.gold,
            "key_reward": 0,
            "trophy_reward": 0,
            "star_key_reward": 0,
            "tokens_doubler": self.player.tokensdoubler,
            "player_tokens": self.player.player_tokens,
            "collected_events": {},
            "tickets": self.player.tickets,
            "available_tokens": self._daily_tokens_cap(),
            "tokens_refill_time": 0,
            "brawler_id": 0,
            "skin_id": 0,
            "trophies": self.player.trophies,
            "highest_trophies": self.player.trophies,
            "profile_icon": 0,
            "brawl_boxes": self.player.brawl_boxes,
            "big_boxes": self.player.big_boxes,
            "first_box_brawler_claimed": 0,
            "free_mega_claimed": 0,
            "do_not_disturb": 0,
            "room_id": 0,
            "unlocked_brawlers": self.player.unlocked_brawlers,
            "friends": {},
            "last_connection_time": 0,
            "player_status": 0,
            "tutorialState": 2,
            "trophyRoad": self.player.trophyRoad,
            "matchmakeSlot": None,
            "matchmakeState": 0,
            "region": self.player.region,
            "unlockedEvents": 1,
            "last_ip": getattr(self.player, "last_ip", "")
        }

        self.cursor.execute("INSERT INTO Players (token, data) VALUES (?, ?)", (self.player.token, json.dumps(data)))
        #self.createOffer(self.player.token)
        self.connection.commit()

    def getAllPlayers(self):
        self.cursor.execute("SELECT data FROM Players")
        results = self.cursor.fetchall()
        return [json.loads(row[0]) for row in results]
    
    def getSpecifiedPlayers(self, tokens):
     if not tokens:
         return []
     players = ",".join(["?"] * len(tokens))
     query = f"SELECT data FROM Players WHERE token IN ({players})"
     self.cursor.execute(query, tokens)
     results = self.cursor.fetchall()
     return [json.loads(row[0]) for row in results]

    def getClubTrophies(self, memberTokens):
        total = 0
        for pdata in self.getSpecifiedPlayers(memberTokens):
            try:
                total += int(pdata.get("trophies", 0) or 0)
            except (TypeError, ValueError):
                continue
        return total

    def getTokenByLowId(self, low_id):
     self.cursor.execute("SELECT token, data FROM Players")
     results = self.cursor.fetchall()
     for token, data in results:
        player_data = json.loads(data)
        if player_data.get('low_id') == low_id:
            return token 
     return None 
    def getSpecifiedValue(self, value_name):
        self.cursor.execute("SELECT data FROM Players WHERE token = ?", (self.player.token,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            return playerData.get(value_name)

    def replaceValue(self, value_name, new_value):
        self.cursor.execute("SELECT data FROM Players WHERE token = ?", (self.player.token,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            playerData[value_name] = new_value
            self.cursor.execute("UPDATE Players SET data = ? WHERE token = ?", (json.dumps(playerData), self.player.token))
            self.connection.commit()
    def replaceOtherValue(self, value_name, new_value, token):
        self.cursor.execute("SELECT data FROM Players WHERE token = ?", (token,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            playerData[value_name] = new_value
            self.cursor.execute("UPDATE Players SET data = ? WHERE token = ?", (json.dumps(playerData), token))
            self.connection.commit()

    def appendElementToArray(self, value_name, element):
        self.cursor.execute("SELECT data FROM Players WHERE token = ?", (self.player.token,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            if value_name in playerData and isinstance(playerData[value_name], list):
                playerData[value_name].append(element)
            else:
                playerData[value_name] = [element]
            self.cursor.execute("UPDATE Players SET data = ? WHERE token = ?", (json.dumps(playerData), self.player.token))
            self.connection.commit()
            

    


    def getRoomId(self):
        self.cursor.execute("SELECT COALESCE(MAX(room_id), 0) FROM Gamerooms")
        self.player.room_id = self.cursor.fetchone()[0] + 1

    def createGameroom(self, roomType, chatData):
        data = {
            "room_id": self.player.room_id,
            "info": {
                "room_type": roomType,
                "map_id": self.player.map_id,
                "player_count": 1,
                "advertiseToBand": False,
                "advertiseToFriends": False,
                "alreadyAdvertisedToBand": False,
                "players": {
                 self.player.low_id: {
                    "host": True,
                    "low_id": self.player.low_id,
                    "name": self.player.name,
                    "team": self.player.team,
                    "ready": self.player.isReady,
                    "status": 3,
                    "brawler_id": self.player.brawler_id,
                    "skin_id": self.player.skin_id,
                    "profile_icon": self.player.profile_icon
                 }
                }
            }
        }
        self.cursor.execute("INSERT INTO Gamerooms (room_id, data) VALUES (?, ?)", (self.player.room_id, json.dumps(data)))
        chatQuery = "INSERT INTO GameroomChats (room_id, data) VALUES (?, ?)"
        self.executeQuery(chatQuery, [self.player.room_id, json.dumps(chatData)])
        self.connection.commit()

    def joinGameroom(self, room_id):
        self.cursor.execute("SELECT data FROM Gamerooms WHERE room_id = ?", (room_id,))
        result = self.cursor.fetchone()
        if not result:
            return False
        data = json.loads(result[0])
        if str(self.player.low_id) in data["info"].get("players", {}):
            return True
        data["info"]["players"][self.player.low_id] = {
            "host": False,
            "low_id": self.player.low_id,
            "name": self.player.name,
            "team": self.player.team,
            "ready": self.player.isReady,
            "status": self.player.player_status,
            "brawler_id": self.player.brawler_id,
            "skin_id": self.player.skin_id,
            "profile_icon": self.player.profile_icon
        }
        data["info"]["player_count"] = len(data["info"]["players"])
        self.cursor.execute("UPDATE Gamerooms SET data = ? WHERE room_id = ?", (json.dumps(data), room_id))
        self.connection.commit()
        return True

    def loadGameroom(self):
        self.cursor.execute("SELECT data FROM Gamerooms WHERE room_id = ?", (self.player.room_id,))
        result = self.cursor.fetchone()
        if result:
            gameroomData = json.loads(result[0])
            return gameroomData.get("info", {})
        else:
            self.player.room_id = 0
            self.replaceValue('room_id', 0)
            return {}

    def getPlayerInfo(self, lowId):
        self.cursor.execute("SELECT data FROM Gamerooms WHERE room_id = ?", (self.player.room_id,))
        result = self.cursor.fetchone()
        if result:
            gameroomData = json.loads(result[0])
            self.playerInfo = gameroomData.get("info", {}).get("players", {}).get(str(lowId))
            return self.playerInfo
        else:
            return None

    def updateGameroomPlayerInfo(self, lowId, roomId, playerInfo):
        query = "SELECT data FROM Gamerooms WHERE room_id = ?"
        data = self.fetchOne(query, [roomId])
        if data:
            gameroomData = json.loads(data[0])
            gameroomData["info"]["players"][str(lowId)] = playerInfo
            updateQuery = "UPDATE Gamerooms SET data = ? WHERE room_id = ?"
            self.executeQuery(updateQuery, [json.dumps(gameroomData), roomId])

    def updateGameroomInfo(self, value, roomId, index):
        query = "SELECT data FROM Gamerooms WHERE room_id = ?"
        data = self.fetchOne(query, [roomId])
        if data:
            gameroomData = json.loads(data[0])
            gameroomData["info"][index] = value
            updateQuery = "UPDATE Gamerooms SET data = ? WHERE room_id = ?"
            self.executeQuery(updateQuery, [json.dumps(gameroomData), roomId])

    def getGameroomInfo(self, index):
        self.cursor.execute("SELECT data FROM Gamerooms WHERE room_id = ?", (self.player.room_id,))
        result = self.cursor.fetchone()
        if result:
            gameroomData = json.loads(result[0])
            self.gameroomInfo = gameroomData[index]
            return self.gameroomInfo
        else:
            return None

    def removeGameroomPlayer(self, lowId, roomId, token):
        query = "SELECT data FROM Gamerooms WHERE room_id = ?"
        data = self.fetchOne(query, [roomId])
        if data:
            gameroomData = json.loads(data[0])
            if str(lowId) in gameroomData["info"]["players"]:
                del gameroomData["info"]["players"][str(lowId)]
                gameroomData["info"]["player_count"] = len(gameroomData["info"]["players"])
                updateQuery = "UPDATE Gamerooms SET data = ? WHERE room_id = ?"
                self.executeQuery(updateQuery, [json.dumps(gameroomData), roomId])
                if gameroomData["info"]["player_count"] == 0:
                    self.removeGameroom(roomId)
                else:
                    updateQuery = "UPDATE Gamerooms SET data = ? WHERE room_id = ?"
                    self.executeQuery(updateQuery, [json.dumps(gameroomData), roomId])
            else:
                print(f"Player with LowID {lowId} not found in RoomID {roomId}.")
        else:
            print(f"Room with ID {roomId} not found.")
        self.replaceOtherValue('room_id', 0, token)

    def removeGameroom(self, lowId):
        deleteQuery = "DELETE FROM Gamerooms WHERE room_id = ?"
        self.executeQuery(deleteQuery, [lowId])
        deleteQuery = "DELETE FROM GameroomChats WHERE room_id = ?"
        self.executeQuery(deleteQuery, [lowId])

    def loadRoomMessages(self, roomId):
        query = "SELECT data FROM GameroomChats WHERE room_id = ?"
        data = self.fetchOne(query, [roomId])
        if data:
            return json.loads(data[0])
        return None

    def getNextGameroomKey(self, roomId):
        query = "SELECT data FROM GameroomChats WHERE room_id = ?"
        data = self.fetchOne(query, [roomId])
        nextKey = 0
        if data:
            chatData = json.loads(data[0])
            messages = chatData["info"]["messages"]
            nextKey = str(max(map(int, messages.keys())) + 1 if messages else 0)
            try:
                return int(nextKey)
            except Exception:
                return 0
        return 0

    def addGameroomMsg(self, roomId, eventType, playerId, playerName, msg, event, targetID = 0, targetName = ""):
        query = "SELECT data FROM GameroomChats WHERE room_id = ?"
        data = self.fetchOne(query, [roomId])
        if data:
            chatData = json.loads(data[0])
            messages = chatData["info"]["messages"]
            nextKey = str(max(map(int, messages.keys())) + 1 if messages else 0)
            messages[nextKey] = {
                "EventType": eventType,
                "Event": event,
                "Tick": int(nextKey)+1,
                "PlayerID": playerId,
                "PlayerName": playerName,
                "Message": msg,
                "promotedTeam": self.player.room_id,
                "TimeStamp": time.time(),
                "targetID": targetID,
                "targetName": targetName
            }
            updateQuery = "UPDATE GameroomChats SET data = ? WHERE room_id = ?"
            self.executeQuery(updateQuery, [json.dumps(chatData), roomId])

    def executeQuery(self, query, params=None):
        if params is None:
            params = []
        self.cursor.execute(query, params)
        self.connection.commit()

    def fetchOne(self, query, params=None):
        if params is None:
            params = []
        self.cursor.execute(query, params)
        return self.cursor.fetchone()

    def fetchAll(self, query, params=None):
        if params is None:
            params = []
        self.cursor.execute(query, params)
        return self.cursor.fetchall()
    




     
    


    def createClub(self, clubId, clubData, chatData):
        clubQuery = "INSERT INTO Clubs (club_id, data) VALUES (?, ?)"
        chatQuery = "INSERT INTO ClubChats (club_id, data) VALUES (?, ?)"
        self.executeQuery(clubQuery, [clubId, json.dumps(clubData)])
        self.executeQuery(chatQuery, [clubId, json.dumps(chatData)])

    def countClubs(self, minMembers, maxMembers, clubType, maxListLength):
     query = "SELECT club_id, data FROM Clubs"
     allClubs = self.fetchAll(query)
     clubList = []
     clubData = []

     for clubId, clubJson in allClubs:
        clubInfo = json.loads(clubJson)
        totalMembers = len(clubInfo.get("info", {}).get("memberCount", []))  # Access "memberCount" directly
        if minMembers <= totalMembers < maxMembers and clubInfo.get("info", {}).get("clubType", 1) <= clubType:
            clubList.append(clubId)
            clubData.append(clubInfo)
            if len(clubList) == maxListLength:
                break

     return [clubList, clubData]
 
    def getClubId(self):
        self.cursor.execute("SELECT COALESCE(MAX(club_id), 0) FROM Clubs")
        self.player.club_id = self.cursor.fetchone()[0] + 1


    def loadClub(self, clubId):
        query = "SELECT data FROM Clubs WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        if data:
            return json.loads(data[0])
        return None
    
    def getMemberData(self, token):
        query = "SELECT data FROM Players WHERE token = ?"
        data = self.fetchOne(query, [token])
        if data:
            return json.loads(data[0])
        return None

    def addMember(self, clubId, playerToken, action):
        query = "SELECT data FROM Clubs WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        if data:
            clubData = json.loads(data[0])
            if action == 0:
                deleteQuery = "DELETE FROM Clubs WHERE club_id = ?"
                self.executeQuery(deleteQuery, [clubId])
                self.executeQuery("DELETE FROM ClubChats WHERE club_id = ?", [clubId])
            elif action == 1:
                if playerToken not in clubData["info"]["memberCount"]:
                    clubData["info"]["memberCount"].append(playerToken)
                updateQuery = "UPDATE CLubs SET data = ? WHERE club_id = ?"
                self.executeQuery(updateQuery, [json.dumps(clubData), clubId])
            elif action == 2:
                if playerToken in clubData["info"]["memberCount"]:
                    clubData["info"]["memberCount"].remove(playerToken)
                updateQuery = "UPDATE Clubs SET data = ? WHERE club_id = ?"
                self.executeQuery(updateQuery, [json.dumps(clubData), clubId])

    def replaceClubValue(self, clubId, description, badgeId, clubType, trophiesNeeded):
        query = "SELECT data FROM Clubs WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        if data:
            clubData = json.loads(data[0])
            clubData["info"]["description"] = description
            clubData["info"]["clubBadge"] = badgeId
            clubData["info"]["clubType"] = clubType
            clubData["info"]["requiredTrophies"] = trophiesNeeded
            updateQuery = "UPDATE CLubs SET data = ? WHERE club_id = ?"
            self.executeQuery(updateQuery, [json.dumps(clubData), clubId])
            
    def loadClubMessages(self, clubId):
        query = "SELECT data FROM ClubChats WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        if data:
            return json.loads(data[0])
        return None
    
    def loadEvents(self, state):
        query = "SELECT data FROM Events WHERE state = ?"
        data = self.fetchOne(query, [state])
        if data:
            return json.loads(data[0])
        return None
    
    def loadPlayerOffers(self, token):
        query = "SELECT data FROM PlayerOffers WHERE PlayerToken = ?"
        data = self.fetchOne(query, [token])
        if data:
            return json.loads(data[0])
        return None
    
    def createOffers(self, token):
        self.cursor.execute("SELECT COUNT(*) FROM PlayerOffers WHERE PlayerToken = ?", (token,))
        count = self.cursor.fetchone()[0]
        data = {
            
        }

        self.cursor.execute("INSERT INTO Players (token, data) VALUES (?, ?)", (self.player.token, json.dumps(data)))
        self.createOffer(self.player.token)
        self.connection.commit()
    
    def rerollEvents(self):
        
        self.cursor.execute("SELECT state, data FROM Events WHERE state = ?", [1])
        results = self.cursor.fetchall()
        for state, row in results:
            event = json.loads(row)
            updatedData = json.dumps(event)
        updateQuery = "UPDATE Events SET data = ? WHERE state = ?"
        self.cursor.execute(updateQuery, [updatedData, 2])
        for state, row in results:
            event = json.loads(row)
            
            eventData = event["info"]["events"]

            now = datetime.now()
            tomorrow = now + timedelta(days=1)
            timestamp = int(tomorrow.replace(hour=10, minute=0, second=0, microsecond=0).timestamp())
            for key, data in eventData.items():
                data["TimeStamp"] = timestamp
                if int(key) == 0:
                    gamemodes = Locations.getAllLocationsWithGamemode("CoinRush")
                elif int(key) == 1:
                    gamemodes = Locations.getAllLocationsWithGamemode("BattleRoyale")
                elif int(key) == 2:
                    gamemodes = Locations.getAllLocationsWithException(["CoinRush", "BattleRoyale", "Survival", "BossFight", "BattleRoyaleTeam"])
                elif int(key) == 3:
                    gamemodes = Locations.getAllLocationsWithException(["Survival", "BossFight"])
                else:
                    gamemodes = Locations.getAllLocationsWithGamemode("BattleRoyaleTeam")
                data["ID"] = random.choice(gamemodes)
                data["Modifier"] = {str(random.randint(0, 4)): 1} if int(key) not in [3, 5] else {str(random.randint(1, 3)): random.randint(10, 50)}

        # Convert the modified event back to JSON and update in DB
            updatedData = json.dumps(event)
            updateQuery = "UPDATE Events SET data = ? WHERE state = ?"
            self.cursor.execute(updateQuery, [updatedData, state])

        self.connection.commit()
    
    def getNextKey(self, clubId):
        query = "SELECT data FROM ClubChats WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        nextKey = 0
        if data:
            chatData = json.loads(data[0])
            messages = chatData["info"]["messages"]
            nextKey = str(max(map(int, messages.keys())) + 1 if messages else 0)
            try:
               return int(nextKey)
            except:
               return 0
        return 0

    def addMsg(self, clubId, eventType, playerId, playerName, role, msg, event, targetID = 0, targetName = ""):
        query = "SELECT data FROM ClubChats WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        if data:
            chatData = json.loads(data[0])
            messages = chatData["info"]["messages"]
            nextKey = str(max(map(int, messages.keys())) + 1 if messages else 0)
            messages[nextKey] = {
                "EventType": eventType,
                "Event": event,
                "Tick": int(nextKey)+1,
                "PlayerID": playerId,
                "PlayerName": playerName,
                "PlayerRole": role,
                "Message": msg,
                "promotedTeam": self.player.room_id,
                "TimeStamp": time.time(),
                "targetID": targetID,
                "targetName": targetName
            }
            updateQuery = "UPDATE ClubChats SET data = ? WHERE club_id = ?"
            self.executeQuery(updateQuery, [json.dumps(chatData), clubId])
            
    def replaceMessageValue(self, tick, value_name, new_value):
        self.cursor.execute("SELECT data FROM ClubChats WHERE club_id = ?", (self.player.club_id,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            playerData["info"]["messages"][str(tick-1)][value_name] = new_value
            self.cursor.execute("UPDATE ClubChats SET data = ? WHERE club_id = ?", (json.dumps(playerData), self.player.club_id))
            self.connection.commit()
            
    
            
    def createMMPool(self, index, selectedBrawler):
      data = {
        "slot": index,
        "info": {
            "PlayerCount": 1,
            "map": 0,
            "players": {self.player.token: selectedBrawler}
        }
      }
      self.cursor.execute("INSERT INTO Matchmake (slot, data) VALUES (?, ?)", (index, json.dumps(data)))
      self.conn.commit()
    def joinMMPool(self, index, brawlerID):
      self.cursor.execute("SELECT data FROM Matchmake WHERE slot = ?", (index,))
      result = self.cursor.fetchone()
      if result:
        data = json.loads(result[0])

        data["info"]["PlayerCount"] += 1
        data["info"]["players"][self.player.token] = brawlerID

        self.cursor.execute("UPDATE Matchmake SET data = ? WHERE slot = ?", (json.dumps(data), index))
        self.conn.commit()
    def leaveMMPool(self, index):
     self.cursor.execute("SELECT data FROM Matchmake WHERE slot = ?", (index,))
     result = self.cursor.fetchone()
     if result:
        data = json.loads(result[0])

        if data["info"]["PlayerCount"] == 1:
            self.cursor.execute("DELETE FROM Matchmake WHERE slot = ?", (index,))
        else:
            if self.player.token in data["info"]["players"]:
                del data["info"]["players"][self.player.token]
                data["info"]["PlayerCount"] -= 1

                self.cursor.execute("UPDATE Matchmake SET data = ? WHERE slot = ?", (json.dumps(data), index))
        self.conn.commit()

    def loadMMPool(self, index):
      self.cursor.execute("SELECT data FROM Matchmake WHERE slot = ?", (index,))
      result = self.cursor.fetchone()
      if result:
        data = json.loads(result[0])
        self.slot = data["slot"]
        self.playercount = data["info"]["PlayerCount"]
        self.map = data["info"]["map"]
        self.matchmakedata = data["info"]["players"]
      else:
        raise IndexError(f"Matchmaking pool not found for slot {index}")
    def removeMMPool(self, index):
     self.cursor.execute("DELETE FROM MatchmakingPool WHERE slot = ?", (index,))
     self.conn.commit()


    def __del__(self):
        self.connection.close()
