from Utils.Writer2 import Writer
from Entries.StreamEntry import StreamEntry
from Database.DatabaseManager import DataBase
from Logic.Player import Players
class AllianceEventStreamEntry:
    def encode(self: Writer, info):
        StreamEntry.encode(self, info)
        
        self.writeVInt(info['Event'])
        self.writeBoolean(True)
        self.writeLogicLong(0, info["targetID"])
        playerCache = getattr(self, "_player_display_cache", None)
        if playerCache is not None:
            try:
                playerData = playerCache.get(int(info["targetID"]), {})
            except (TypeError, ValueError):
                playerData = {}
        else:
            db = DataBase(self.player)
            playertoken = db.getTokenByLowId(info["targetID"])
            playersData = db.getSpecifiedPlayers([playertoken]) if playertoken else []
            playerData = playersData[0] if playersData else {}
        self.writeString(playerData.get('name', info.get("targetName", "")))

