from Utils.Writer import Writer
from Entries.PlayerDisplayData import PlayerDisplayData
import time
class FriendEntry:
    
    def encode(ByteStream: Writer, player, db):
        playerToken = db.getTokenByLowId(player["low_id"])
        ByteStream.writeLong(0, player["low_id"]) # FriendID?

        ByteStream.writeString(player['name']) # FriendName
        ByteStream.writeString("ho") #facebook id
        ByteStream.writeString() # gamecenter id
        ByteStream.writeString() # why sc sends useless datas!!!!!

        ByteStream.writeInt(0 if playerToken not in ByteStream.player.friends else ByteStream.player.friends[playerToken]) # friend state
        ByteStream.writeInt(player["trophies"]) # trophies
        ByteStream.writeInt(0) # Unknown
        ByteStream.writeInt(0) # Unknown
        ByteStream.writeInt(0) # Unknown
        ByteStream.writeInt(0)

        ByteStream.writeBoolean(player["club_id"] != 0) # Is in Band
        if player["club_id"] != 0:
                club = db.loadClub(player["club_id"])
                ByteStream.writeInt(0)
                ByteStream.writeInt(0)
                ByteStream.writeInt(0)
                ByteStream.writeString(club["info"]["name"])
                ByteStream.writeInt(0)
                ByteStream.writeInt(0)    
        ByteStream.writeString("you")
        ByteStream.writeInt(28000000 + player["profile_icon"])
        ByteStream.writeInt(20000)
        #PlayerDisplayData.encode(ByteStream)