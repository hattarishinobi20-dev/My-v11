from Utils.Writer2 import Writer
from Entries.StreamEntry import StreamEntry
from Entries.PlayerDisplayData import PlayerDisplayData
from Database.DatabaseManager import DataBase

class JoinRequestAllianceStreamEntry:
    def encode(self: Writer, info):
        StreamEntry.encode(self, info)
        playerCache = getattr(self, "_player_display_cache", None)
        if playerCache is not None:
            try:
                playerData = playerCache.get(int(info["PlayerID"]), {})
            except (TypeError, ValueError):
                playerData = {}
        else:
            db = DataBase(self.player)
            playerToken = db.getTokenByLowId(info["PlayerID"])
            playersData = db.getSpecifiedPlayers([playerToken]) if playerToken else []
            playerData = playersData[0] if playersData else {}
        self.writeString(info["Message"]) # promotion message
        self.writeString(info["PlayerName"]) # who accepted/rejected the player
        self.writeVInt(info["Event"]) # state (0: rejected, 1: pending, 2: accepted)
        self.writeVInt(0) # little thing wrote on pfp wth
        self.writeDataReference(28, playerData.get("profile_icon", 0)) # player pfp

