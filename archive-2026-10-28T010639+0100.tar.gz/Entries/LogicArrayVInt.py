from datetime import datetime
from Utils.Helpers import Helpers
from Utils.Writer import Writer

class LogicArrayVInt:
    def encode(self: Writer, list):
        self.writeVInt(len(list))
        for element in list:
            self.writeVInt(element)
