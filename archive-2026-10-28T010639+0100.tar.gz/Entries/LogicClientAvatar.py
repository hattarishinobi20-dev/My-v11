from datetime import datetime
from Utils.Helpers import Helpers
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Logic.EventSlots import EventSlots
from Logic.Shop import Shop
from Entries.LogicDailyData import LogicDailyData
from Entries.LogicConfData import LogicConfData
from Files.CsvLogic.Cards import Cards

V11_MAX_BRAWLER_ID = 20
V11_MAX_CARD_ID = 104


def _brawlers_v11(player):
    """Filtra o dict unlocked_brawlers para o que o cliente 11.112 conhece."""
    result = {}
    for key, data in player.unlocked_brawlers.items():
        try:
            char_id = int(key)
        except (TypeError, ValueError):
            continue
        if char_id < 0 or char_id > V11_MAX_BRAWLER_ID:
            continue
        if data.get("CardID", 0) > V11_MAX_CARD_ID:
            continue
        result[key] = data
    return result


class LogicClientAvatar:
    def encode(self: Writer):
        brawlers = _brawlers_v11(self.player)

        self.writeVInt(self.player.high_id) #HighID
        self.writeVInt(self.player.low_id) #LowID

        self.writeVInt(self.player.high_id) #HighID
        self.writeVInt(self.player.low_id) #LowID

        self.writeVInt(self.player.high_id) #HighID
        self.writeVInt(self.player.low_id) #LowID

        self.writeString(self.player.name)
        self.writeBoolean(self.player.name != "Brawler")  # namesetbyuser

        self.writeString()

        self.writeVInt(8)  # Commodity count


        self.writeVInt(len(brawlers) + 3)

        for key, unlock_id in brawlers.items():
            self.writeVInt(23)
            self.writeVInt(unlock_id["CardID"])
            self.writeVInt(1)

        self.writeVInt(5)
        self.writeVInt(1)
        self.writeVInt(self.player.brawl_boxes) #Brawl Box tokens

        self.writeVInt(5)
        self.writeVInt(8)
        self.writeVInt(self.player.gold) #Gold

        self.writeVInt(5)
        self.writeVInt(9)
        self.writeVInt(self.player.big_boxes) #Big Box tokens

        # Brawlers Trophies array
        self.writeVInt(len(brawlers))  # brawlers count
        for key, brawler_id in brawlers.items():
            self.writeDataReference(16, int(key))
            self.writeVInt(brawler_id["Trophies"])

        # Brawlers Trophies for Rank array
        self.writeVInt(len(brawlers))  # brawlers count
        for key, brawler_id in brawlers.items():
            self.writeDataReference(16, int(key))
            self.writeVInt(brawler_id["HighestTrophies"])

        self.writeVInt(0)  # array

        # Brawlers Upgrade Points array
        self.writeVInt(len(brawlers))  # brawlers count
        for key, brawler_id in brawlers.items():
            self.writeDataReference(16, int(key))
            self.writeVInt(brawler_id["PowerPoints"])

        # Brawlers Power Level array
        self.writeVInt(len(brawlers))  # brawlers count
        for key, brawler_id in brawlers.items():
            self.writeDataReference(16, int(key))
            self.writeVInt(brawler_id["PowerLevel"])

        self.writeVInt(len(brawlers))  # brawlers count
        for key, brawler_id in brawlers.items():
            self.writeDataReference(16, int(key))
            self.writeVInt(brawler_id["PowerLevel"])

        self.writeVInt(len(brawlers))  # brawlers count
        for key, brawler_id in brawlers.items():
            star_card_id = Cards.get_brawler_star_power(int(key))
            self.writeDataReference(23, star_card_id)
            self.writeVInt(1 if brawler_id["StarPower"] != 0 else 0)



        self.writeVInt(self.player.gems)  # Player Gems
        self.writeVInt(self.player.gems)  # Free Gems
        self.writeVInt(self.player.player_experience) # Tips Related
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(self.player.tutorialState)
