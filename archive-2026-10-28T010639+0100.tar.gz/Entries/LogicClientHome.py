from datetime import datetime
from Utils.Helpers import Helpers
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Logic.EventSlots import EventSlots
from Logic.Shop import Shop
from Entries.LogicDailyData import LogicDailyData
from Entries.LogicConfData import LogicConfData

class LogicClientHome:
    def encode(self: Writer):
        LogicDailyData.encode(self)
        
        LogicConfData.encode(self)
        self.writeLong(0, self.player.low_id)
        self.writeVInt(0) # true notifs array
        #self.writeBoolean(False)
        #self.writeVInt(0) # an array...
