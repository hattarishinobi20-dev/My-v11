from datetime import datetime
from Utils.Helpers import Helpers
from Utils.Writer import Writer
from Entries.LogicGemOffer import LogicGemOffer
import time
class LogicOfferBundle:
    def encode(self: Writer, item):
         self.writeVInt(1) # items amount  
         for amount in range(1):
            LogicGemOffer.encode(self, item, amount)
         self.writeVInt(item['Currency']) #Currency 
         self.writeVInt(item['Price']) # price
         self.writeVInt(item['Timer'] - int(time.time())) # time left
         self.writeVInt(item['IsOfferSeen']) #is offer seen
         self.writeVInt(115) #??
         self.writeByte(item['IsOfferPurchased']) #is purchased
