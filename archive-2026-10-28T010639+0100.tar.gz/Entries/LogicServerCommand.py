from Utils.Writer import Writer
from Entries.LogicCommand import LogicCommand

class LogicServerCommand:
    
    def encode(ByteStream: Writer):
        ByteStream.writeVInt(0) # hmm what
        LogicCommand.encode(ByteStream)