from Utils.Writer2 import Writer
import time
from Database.DatabaseManager import DataBase
from Logic.Player import Players

class StreamEntry:
    def encode(ByteStream: Writer, info):
        ByteStream.writeLogicLong(0, info["Tick"]) # StreamEntryID
        ByteStream.writeLogicLong(0, info["PlayerID"]) # TargetID
        playerCache = getattr(ByteStream, "_player_display_cache", None)
        if playerCache is not None:
            try:
                playerData = playerCache.get(int(info["PlayerID"]), {})
            except (TypeError, ValueError):
                playerData = {}
        else:
            db = DataBase(ByteStream.player)
            playertoken = db.getTokenByLowId(info["PlayerID"])
            playersData = db.getSpecifiedPlayers([playertoken]) if playertoken else []
            playerData = playersData[0] if playersData else {}
        ByteStream.writeString(playerData.get('name', info.get("PlayerName", "")))
        try:
            ByteStream.writeVInt(info['PlayerRole'])
        except:
            ByteStream.writeVInt(0)
        ByteStream.writeVInt(int(time.time() - info['TimeStamp']))
        ByteStream.writeBoolean(False)

