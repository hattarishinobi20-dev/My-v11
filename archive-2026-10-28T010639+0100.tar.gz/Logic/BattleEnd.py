from threading import Thread
from Database.DatabaseManager import DataBase
import time
from Packets.Messages.Server.Battle.BattleResultMessage import BattleResultMessage
from Logic.Battle import Battle

class BattleEnd(Thread):
    def __init__(self, client, player, device):
        Thread.__init__(self)
        self.client = client
        self.device = device
        self.player = player

    def run(self):
        name = []
        team = []
        low_id = []
        brawler_id = []
        skin_id = []
        trophies = []
        level = []
        token = []
        three_v_three = []
        slotstat = []
        slotcoins = []
        slotexp = []
        experience = []
        highestTrophies = []
        coins = []
        dummyBrawlers = []
        DataBase.loadMMPool(self, self.player.MapIndex)
        for x in range(self.playercount):
            name.append(self.matchmakedata[str(x)]["name"])
            team.append(self.matchmakedata[str(x)]["Team"])
            low_id.append(self.matchmakedata[str(x)]["lowID"])
            brawler_id.append(self.matchmakedata[str(x)]["brawlerID"])
            skin_id.append(self.matchmakedata[str(x)]["skinID"])
            trophies.append(self.matchmakedata[str(x)]["trophies"])
            level.append(self.matchmakedata[str(x)]["level"])
            token.append(self.matchmakedata[str(x)]["token"])
            three_v_three.append(self.matchmakedata[str(x)]["3vs3Wins"])
            slotstat.append(self.matchmakedata[str(x)]["slotstats"])
            slotcoins.append(self.matchmakedata[str(x)]["slotcoins"])
            slotexp.append(self.matchmakedata[str(x)]["slotexperiences"])
            experience.append(self.matchmakedata[str(x)]["experience"])
            highestTrophies.append(self.matchmakedata[str(x)]["highestTrophies"])
            coins.append(self.matchmakedata[str(x)]["coins"])

        #BattleResultMessage(self.client, self.player, self.device, self.player.MapIndex, 1, self.playercount, name, team, low_id, brawler_id, skin_id, trophies, level, token, three_v_three, slotstat, slotcoins, slotexp, experience, highestTrophies, coins, self.dummyBrawlers).send()

        #for x in range(self.playercount):
            #DataBase.replaceValueSpecifiedToken(self, 'mmstat', 3, token[x])
            #time.sleep(0.25)
