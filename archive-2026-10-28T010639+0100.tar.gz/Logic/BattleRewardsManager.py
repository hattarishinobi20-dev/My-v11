import json
import time
from Logic.Milestones import Milestones


class BattleRewardsManager:
    def __init__(self, player, db):
        self.player = player
        self.db = db
        self.milestones = Milestones()

    def get_trophy_modifiers(self, trophies):
        ranges = [
            (0, 29, (0, 0, 6)),
            (30, 59, (-1, 0, 6)),
            (60, 99, (-2, 0, 6)),
            (100, 139, (-2, 0, 5)),
            (140, 219, (-3, 0, 5)),
            (220, 299, (-4, 0, 5)),
            (300, 499, (-5, 0, 5)),
            (500, 599, (-6, 0, 5)),
            (600, 699, (-7, 0, 4)),
            (700, 799, (-7, 0, 3)),
            (800, 899, (-8, 0, 3)),
            (900, float("inf"), (-9, 0, 2)),
        ]
        for low, high, modifiers in ranges:
            if low <= trophies <= high:
                return modifiers
        return (0, 0, 0)

    def get_solo_trophy_modifiers(self, trophies):
        trophy_ranges = [
            (0, 29, [8, 7, 6, 5, 5, 4, 3, 2, 1, 0]),
            (30, 59, [8, 7, 6, 4, 3, 2, 0, -1, -2, -4]),
            (60, 99, [8, 7, 5, 4, 3, 1, 0, -2, -3, -4]),
            (100, 139, [7, 6, 5, 3, 2, 1, -1, -2, -3, -4]),
            (140, 219, [7, 6, 4, 3, 2, 0, -1, -3, -4, -5]),
            (220, 299, [7, 6, 4, 3, 1, 0, -2, -3, -4, -5]),
            (300, 499, [7, 6, 4, 2, 1, -1, -2, -4, -6, -7]),
            (500, 599, [6, 5, 3, 2, 0, -2, -3, -4, -6, -7]),
            (600, 699, [5, 4, 3, 1, -1, -2, -3, -4, -6, -7]),
            (700, float("inf"), [5, 3, 2, 1, -1, -2, -4, -5, -6, -7]),
        ]

        for low, high, rank_trophies in trophy_ranges:
            if low <= trophies <= high:
                return rank_trophies
        return [0] * 10

    def process_rewards(self, fields):
        self.fields = fields
        battle_end_key = self.fields.get("BattleEndKey")
        cached_rewards = getattr(self.player, "lastBattleEndRewards", None)
        if battle_end_key is not None and cached_rewards is not None and getattr(self.player, "lastBattleEndKey", None) == battle_end_key and time.time() - getattr(self.player, "lastBattleEndTime", 0) < 15:
            return dict(cached_rewards)
        heroes = self.fields.get("Heroes") or []
        local_hero = {}
        for hero in heroes:
            if hero.get("IsPlayer"):
                local_hero = hero
                break
        if not local_hero and heroes:
            local_hero = heroes[0]
        brawler_ref = (local_hero.get("Brawler") or {}).get("ID") or [16, getattr(self.player, "brawler_id", 0) or 0]
        self.brawler_key = str(brawler_ref[1])
        unlocked = getattr(self.player, "unlocked_brawlers", None)
        if not isinstance(unlocked, dict):
            unlocked = {}
            self.player.unlocked_brawlers = unlocked
        stats = unlocked.get(self.brawler_key)
        if stats is None:
            try:
                stats = unlocked.get(int(brawler_ref[1]))
            except (TypeError, ValueError):
                stats = None
        self.brawler_stats = stats if isinstance(stats, dict) else {"Trophies": 0, "HighestTrophies": 0}
        self.brawler_stats_owned = isinstance(stats, dict)
        self.local_hero = local_hero
        try:
            rank_value = int(self.fields.get("Rank", 1))
        except (TypeError, ValueError):
            rank_value = 1
        try:
            victory_value = int(self.fields.get("Victory", 1))
        except (TypeError, ValueError):
            victory_value = 1
        self.brawler_trophies = self.brawler_stats.get("Trophies", 0)
        self.brawler_trophies_in_rank = self.brawler_stats.get("HighestTrophies", 0)
        self.hasStarKey = False
        self.is_win = False
        if self.fields["GameMode"] == 2:
            self.rank = min(10, max(1, rank_value))
            self.rank_trophies = self.get_solo_trophy_modifiers(self.brawler_trophies)
            if self.rank <= 4:
                self.hasStarKey = True
            self.is_win = self.rank == 1
        elif self.fields["GameMode"] == 5:
            self.rank = min(5, max(1, rank_value))
            self.rank_trophies = self.get_duo_trophy_modifiers(self.brawler_trophies)
            if self.rank <= 2:
                self.hasStarKey = True
            self.is_win = self.rank == 1
        else:
            self.rank_trophies = self.get_trophy_modifiers(self.brawler_trophies)
            self.rank = {0: 3, 1: 1, 2: 2, 3: 3}.get(victory_value, 1)
            if victory_value in (0, 3):
                self.hasStarKey = True
                self.is_win = True

        

        # Rewards per rank
        if self.fields["GameMode"] == 2:
            self.exp_rewards = [0, 1, 2, 3, 4, 5, 6, 9, 12, 15]
            self.token_rewards = [0, 2, 4, 6, 8, 12, 16, 22, 28, 34]
        elif self.fields["GameMode"] == 5:
            self.exp_rewards = [0, 2, 4, 8, 14]
            self.token_rewards = [0, 4, 8, 20, 32]

        else:
            self.exp_rewards = [4, 6, 8]
            self.token_rewards = [10,15,20]
            

        # Determine rewards
        self.trophies_gain = self.rank_trophies[self.rank - 1] if self.player.tutorialState == 2 else 0
        self.experience_gain = self.exp_rewards[self.rank - 1] if self.player.tutorialState == 2 else 0
        self.tokens_gain = self.token_rewards[self.rank - 1] if self.player.tutorialState == 2 else 0
        if self.local_hero.get("IsPlayer"):
            self.experience_gain += 10 if self.player.tutorialState == 2 else 0
            self.star_player_exp = 10 if self.player.tutorialState == 2 else 0
            self.exp_rewards_array = {0: self.experience_gain, 8: self.star_player_exp}
        else:
            self.star_player_exp = 0
            self.exp_rewards_array = {0: self.experience_gain}

        # Token doubler handling
        self.doubled_tokens = min(self.tokens_gain, self.player.tokensdoubler)
        _pool = self.db.refresh_tokens()
        _base_granted = min(self.tokens_gain, _pool)
        _doubled_granted = min(self.doubled_tokens, _pool - _base_granted)
        self.db.consume_tokens(_base_granted + _doubled_granted)
        self.tokens_gain = _base_granted
        self.doubled_tokens = _doubled_granted
        self.remaining_tokens = self.player.tokensdoubler - self.doubled_tokens
        self.total_tokens = self.tokens_gain + self.doubled_tokens

        # Apply rewards
        self.milestonesRewardRank = 0
        self.brawler_stats["Trophies"] = self.brawler_stats.get("Trophies", 0) + self.trophies_gain
        if self.brawler_stats.get("HighestTrophies", 0) < self.brawler_stats["Trophies"]:
            self.brawler_stats["HighestTrophies"] = self.brawler_stats["Trophies"]
        for milestone in self.milestones.rankTrophies:
            if self.brawler_trophies < milestone and self.brawler_stats["Trophies"] >= milestone:
                self.milestonesRewardRank = 10

        if self.player.tutorialState == 2:
            if self.hasStarKey:
                self.player.starkeysReward = 1
                self.player.big_boxes += 1
            if self.is_win and self.fields["GameMode"] == 2:
                self.player.solo_wins = getattr(self.player, "solo_wins", 0) + 1
                self.db.replaceValue("solo_wins", self.player.solo_wins)
            elif self.is_win and self.fields["GameMode"] == 5:
                self.player.duo_wins = getattr(self.player, "duo_wins", 0) + 1
                self.db.replaceValue("duo_wins", self.player.duo_wins)
            elif self.is_win:
                self.player.three_vs_three_wins = getattr(self.player, "three_vs_three_wins", 0) + 1
                self.db.replaceValue("three_vs_three_wins", self.player.three_vs_three_wins)
            self.player.player_experience += self.experience_gain + self.star_player_exp
            self.player.tokensdoubler = self.remaining_tokens
            self.player.brawl_boxes += self.total_tokens
            self.player.trophies += self.trophies_gain
            if self.player.trophies > self.player.highest_trophies:
                self.player.highest_trophies = self.player.trophies
            self.player.trophy_reward = self.trophies_gain
            self.player.key_reward = self.total_tokens
            self.player.star_key_reward = 1 if self.hasStarKey else 0
            self.db.replaceValue("key_reward", self.player.key_reward)
            self.db.replaceValue("trophy_reward", self.player.trophy_reward)
            self.db.replaceValue("star_key_reward", self.player.star_key_reward)
            self.db.replaceValue("unlocked_brawlers", self.player.unlocked_brawlers)
            self.db.replaceValue("player_experience", self.player.player_experience)
            self.db.replaceValue("tokens_doubler", self.player.tokensdoubler)
            self.db.replaceValue("brawl_boxes", self.player.brawl_boxes)
            self.db.replaceValue("big_boxes", self.player.big_boxes)
            self.db.replaceValue("trophies", self.player.trophies)
            self.db.replaceValue("highest_trophies", self.player.highest_trophies)
        else:
           pass
        rewards = {"tokens_gain": self.tokens_gain, "trophies_gain": self.trophies_gain, "doubled_tokens": self.doubled_tokens, "remaining_tokens": self.remaining_tokens, "exp_rewards_array": self.exp_rewards_array, "brawler_trophies": self.brawler_trophies, "brawler_trophies_for_rank": self.brawler_trophies_in_rank, "experience": self.experience_gain, "star_player_exp": self.star_player_exp, "hasStarKey": self.hasStarKey}
        if battle_end_key is not None:
            self.player.lastBattleEndKey = battle_end_key
            self.player.lastBattleEndRewards = dict(rewards)
            self.player.lastBattleEndTime = time.time()
        return rewards
    

    def get_duo_trophy_modifiers(self, trophies):
        trophy_ranges = [
            (0, 29, [7, 5, 4, 2, 0]),
            (30, 59, [7, 5, 2, -1, -3]),
            (60, 99, [7, 4, 2, -1, -4]),
            (100, 139, [6, 4, 1, -1, -4]),
            (140, 219, [6, 4, 1, -2, -5]),
            (220, 499, [6, 3, 0, -3, -6]),
            (500, 599, [6, 3, 0, -4, -6]),
            (600, 699, [4, 2, -1, -4, -6]),
            (700, 799, [3, 1, -1, -4, -6]),
            (800, 899, [3, 1, -2, -5, -7]),
            (900, float("inf"), [2, 0, -3, -5, -7]),
        ]

        for low, high, rank_trophies in trophy_ranges:
            if low <= trophies <= high:
                return rank_trophies
        return [0] * 5

    