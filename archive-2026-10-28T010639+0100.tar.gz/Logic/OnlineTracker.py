import threading
import time

_lock = threading.Lock()
_online = {}


def player_online(low_id):
    if not low_id:
        return
    with _lock:
        _online[int(low_id)] = time.time()


def touch(low_id):
    player_online(low_id)


def player_offline(low_id):
    if not low_id:
        return
    with _lock:
        _online.pop(int(low_id), None)


def is_online(low_id, max_age=90):
    if not low_id:
        return False
    with _lock:
        last = _online.get(int(low_id))
    if last is None:
        return False
    return (time.time() - last) <= max_age


def count_online(low_ids, max_age=90):
    now = time.time()
    with _lock:
        snapshot = dict(_online)
    total = 0
    for low_id in low_ids:
        try:
            last = snapshot.get(int(low_id))
        except (TypeError, ValueError):
            continue
        if last is not None and (now - last) <= max_age:
            total += 1
    return total
