from Database.DatabaseManager import DataBase
from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.LogicCommand import LogicCommand

class LogicPurchaseBoxCommand(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        fields = {}
        LogicCommand.decode(self, fields, False)
        #LogicCommand.parseFields(fields)
        
        self.box_id = self.readVInt()
        

    def process(self, crypter):
        logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, self.box_id)
        logicBoxDataCommand.getRewards()
        logicBoxDataCommand.send(crypter)
