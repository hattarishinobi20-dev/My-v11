from Database.DatabaseManager import DataBase
from Logic.Shop import Shop
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.LogicCommand import LogicCommand
class LogicPurchaseHeroLvlUpMaterialCommand(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.fields = {}
        LogicCommand.decode(self, self.fields, False)
        self.gold = self.readVInt()


    def process(self, crypter):
        db = DataBase(self.player)
        cost = Shop.gold[self.gold]['Cost']
        value = Shop.gold[self.gold]['Amount']
        if self.player.gems < cost:
            return "kek"
        self.player.gold += value
        self.player.gems -= cost

        db.replaceValue('gold', self.player.gold)
        db.replaceValue('gems', self.player.gems)

