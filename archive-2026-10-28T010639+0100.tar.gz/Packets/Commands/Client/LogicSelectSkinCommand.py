from Database.DatabaseManager import DataBase

from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.LogicCommand import LogicCommand
from Files.CsvLogic.Skins import Skins

class LogicSelectSkinCommand(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        fields = {}
        LogicCommand.decode(self, fields, False)
        self.skin_id = self.readDataReference()


    def process(self, crypter):
        self.fields = {}
        db = DataBase(self.player)
        if not self.skin_id or self.skin_id[1] is None:
            return "kek"
        self.fields["brawler"] = Skins.getBrawler(self.skin_id[1])
        if str(self.fields["brawler"]) not in self.player.unlocked_brawlers:
            return "kek"
        if self.skin_id[1] not in self.player.unlocked_brawlers[str(self.fields["brawler"])]["Skins"]:
            return "kek"
        self.player.unlocked_brawlers[str(self.fields["brawler"])]["selectedSkin"] = self.skin_id[1]
        db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
        
