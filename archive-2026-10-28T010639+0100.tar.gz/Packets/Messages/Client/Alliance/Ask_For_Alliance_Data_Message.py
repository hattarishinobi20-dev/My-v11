from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from random import choice
from string import ascii_uppercase
import json
from Packets.PiranhaMessage import PiranhaMessage


class AskForAllianceDataMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.clubHighID = self.readInt()
        self.clubLowID = self.readInt()

    def process(self, crypter):
        AllianceDataMessage(self.client, self.player, self.clubHighID, self.clubLowID).send(crypter)