from time import daylight
from random import choice
from string import ascii_uppercase
import json
import time
from Logic.Player import Players
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Alliance.Events.AllianceJoinOkMessage import AllianceJoinOkMessage
from Database.DatabaseManager import DataBase
from Utils.Helpers import Helpers

from Packets.PiranhaMessage import PiranhaMessage


class Create_Message(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        # ClubID
        self.clubHighID = 0
        

        # Info
        self.clubName           = self.readString()    # Club name 
        self.clubdescription    = self.readString()    # Club description

        # Badge
        self.BadgeIdentifier    = self.readVInt()      # Badge Identifier
        self.clubbadgeID        = self.readVInt()      # BadgeID
        # Settings
        self.clubtype           = self.readVInt()      # Type
        self.clubtrophiesneeded = self.readVInt()      # Trophy required

    def process(self, crypter):
        db = DataBase(self.player)
        if self.player.club_id != 0:
            return "nop"
        db.getClubId()
        db.replaceValue('club_id', self.player.club_id)
        db.replaceValue('club_role', 2)
        self.player.club_role = 2

        # Club creation
        db.createClub(self.player.club_id, {"info": {"clubID": self.player.club_id, "name": self.clubName, "description": self.clubdescription, "region": self.player.region, "clubBadge": self.clubbadgeID, "clubType": self.clubtype, "requiredTrophies": self.clubtrophiesneeded, "trophies": self.player.trophies, "memberCount": [self.player.token], "onlineMembers": 1}}, {"info": {"clubID": self.player.club_id, "messages": { "0": {"EventType": 4, "Event": 3, "Tick": 1, "PlayerID": self.player.low_id, "PlayerName": self.player.name, "PlayerRole": self.player.club_role, "Message": "", "promotedTeam": 0, "TimeStamp": time.time(), "targetID": self.player.low_id, "targetName": self.player.name}}}})
        
        #db.addMsg(self.player.club_id, 4, self.player.low_id, self.player.name, self.player.club_role, "", 3)

        # Club data
        AllianceJoinOkMessage(self.client, self.player).send(crypter)
        MyAllianceMessage(self.client, self.player, self.player.club_id).send(crypter)
        AllianceStreamMessage(self.client, self.player, self.player.club_id, 0).send(crypter)