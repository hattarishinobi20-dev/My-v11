from Utils.Helpers import Helpers
from Database.DatabaseManager import DataBase
from random import choice
from string import ascii_uppercase
import json

from Logic.Player import Players
from Packets.Messages.Server.Alliance.Events.AllianceEditOkMessage import AllianceEditOkMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage

from Packets.PiranhaMessage import PiranhaMessage


class Edit_Settings_Message(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.clubDescription = self.readString() # Club description

        self.inf2 = self.readVInt() # ID Type
        self.badgeID = self.readVInt() # Club BadgeID


        self.clubType = self.readVInt() # Club type || 1 = open, 2 = invite only, 3 = closed
        self.requiredTrophies = self.readVInt() # Trophy required

    def process(self, crypter):
        db = DataBase(self.player)
        # Replacing value   
        db.replaceClubValue(self.player.club_id, self.clubDescription, self.badgeID, self.clubType, self.requiredTrophies)
        #db.addMsg(self.player.club_id, 4, self.player.low_id, self.player.name, self.player.club_role, self.fields["promotionMessage"], 1)
        # Sending confirmation and updated data
        AllianceEditOkMessage(self.client, self.player).send(crypter)
        MyAllianceMessage(self.client, self.player, self.player.club_id).send(crypter)