from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Utils.Helpers import Helpers
from Database.DatabaseManager import DataBase
from random import choice
from string import ascii_uppercase
import json
from Packets.Messages.Server.Alliance.AllianceEventMessage import AllianceEventMessage
from Logic.Player import Players
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.Events.AllianceLeaveOkMessage import AllianceLeaveOkMessage
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage

from Packets.PiranhaMessage import PiranhaMessage


class KickAllianceMemberMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.fields = {}
        self.fields["playerID"] = self.readLong()
        self.fields["unkString"] = self.readString()
        

    def process(self, crypter):
        db = DataBase(self.player)
        if self.player.club_role == 1:
            return "kek"
        
        # Removing member 
        club =  db.loadClub(self.player.club_id)
        if club is None:
            return "kek"
        playertoken = db.getTokenByLowId(self.fields["playerID"][1])
        if not playertoken:
            return "kek"
        if len(club["info"]["memberCount"]) == 1:
            db.addMember(self.player.club_id, playertoken, 0)

        else:
            db.addMember(self.player.club_id, playertoken, 2)
            db.addMsg(self.player.club_id, 4, self.player.low_id, self.player.name, self.player.club_role, "", 1, self.fields["playerID"][1], self.player.name)

        # Info
        
        #AllianceEventMessage(self.client, self.player).send(crypter)
        MyAllianceMessage(self.client, self.player, self.player.club_id).send(crypter)
        #AllianceDataMessage(self.client, self.player, 0, self.player.club_id).send(crypter)
        db.replaceOtherValue('club_id', 0, playertoken)
        db.replaceOtherValue('club_role', 0, playertoken)