from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.AllianceEventMessage import AllianceEventMessage
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from random import choice
from string import ascii_uppercase
import json
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage

class RequestJoinAllianceMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.fields = {}
        self.fields["clubID"] = self.readLong()
        self.fields["promotionMessage"] = self.readString()

    def process(self, crypter):
        db = DataBase(self.player)
        db.addMsg(self.fields["clubID"][1], 3, self.player.low_id, self.player.name, self.player.club_role, self.fields["promotionMessage"], 1)
        AllianceEventMessage(self.client, self.player, 50)
        