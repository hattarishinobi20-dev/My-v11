from random import choice
from string import ascii_uppercase
import json
from typing import Dict
from Database.DatabaseManager import DataBase
from Logic.Player import Players
from Packets.Messages.Server.Alliance.AllianceSearchResultMessage import AllianceSearchResultMessage
from Utils.IdUtils import IdUtils
from Packets.PiranhaMessage import PiranhaMessage


class Search_Message(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.fields = {}
        self.fields["RequestedName"] = self.readString()
        self.fields["Int1"] = self.readInt()
        self.fields["Int2"] = self.readInt()
        self.fields["Int3"] = self.readInt()
        self.fields["Int4"] = self.readInt()
        self.fields["Booolean"] = self.readBoolean()
        self.fields["Int5"] = self.readInt()
        self.fields["Int6"] = self.readInt()

    def process(self, crypter):
        db = DataBase(self.player)
        idutils = IdUtils()
        clubs = db.countClubs(1, 100, 2, 30)
        self.foundAlliances = []
        try:
            requestedLowId = idutils.getHLId(self.fields["RequestedName"].lower())[1]
        except Exception:
            requestedLowId = -1
        for i in clubs[1]:
            if self.fields["RequestedName"].lower() in i["info"]["name"].lower() or requestedLowId == i["info"]["clubID"]:
                self.foundAlliances.append(i["info"])
        AllianceSearchResultMessage(self.client, self.player, self.fields, self.foundAlliances).send(crypter)