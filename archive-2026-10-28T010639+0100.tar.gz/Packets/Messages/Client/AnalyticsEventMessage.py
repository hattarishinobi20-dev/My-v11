from random import choice
from string import ascii_uppercase
import json

from Logic.Player import Players

from Packets.PiranhaMessage import PiranhaMessage


class AnalyticsEventMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.string1 = self.readString()
        self.string2 = self.readString()

    def process(self, crypter):
        #print(self.string1 + self.string2)
        pass