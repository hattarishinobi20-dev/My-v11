from random import choice
from string import ascii_uppercase
import json
from Packets.Messages.Server.Battle.BattleResultShowdownMessage import BattleResultShowdownMessage
from Packets.Messages.Server.Battle.BattleResultMessage import BattleResultMessage
from Packets.Messages.Server.Battle.BattleResultDuoShowdownMessage import BattleResultDuoShowdownMessage
from Packets.PiranhaMessage import PiranhaMessage
import time
from Database.DatabaseManager import DataBase
from Logic.EventData import EventData
from Files.CsvLogic.Locations import Locations


class AskForBattleEndMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def _resolve_game_mode(self):
        valid_modes = (0, 2, 4, 5)
        candidates = []
        for value in (self.fields.get("EventSlotThing"), self.fields.get("Index")):
            if isinstance(value, int) and 1 <= value <= 6 and value not in candidates:
                candidates.append(value)
        try:
            db = DataBase(self.player)
            for slot in candidates:
                modes = []
                for state in (1, 2):
                    event_data = db.loadEvents(state) or {}
                    event = event_data.get("info", {}).get("events", {}).get(str(slot - 1))
                    if not event:
                        continue
                    mode = EventData.getGameModeVariationBattleEnd(self, event.get("ID", 0))
                    modes.append((event.get("TimeStamp") == getattr(self.player, "lastEventTimeStamp", 0), mode))
                for timestamp_matches, mode in modes:
                    if timestamp_matches and mode in valid_modes:
                        return mode
                for timestamp_matches, mode in modes:
                    if mode in valid_modes:
                        return mode
        except Exception:
            pass
        return 0

    def _local_brawler_stats(self, brawler_id):
        unlocked = getattr(self.player, "unlocked_brawlers", None)
        if not isinstance(unlocked, dict):
            return {}
        stats = unlocked.get(str(brawler_id))
        if stats is None:
            try:
                stats = unlocked.get(int(brawler_id))
            except (TypeError, ValueError):
                stats = None
        return stats if isinstance(stats, dict) else {}

    def decode(self):
        self.fields = {}
        self.fields["isInRealGame"] = True if self.player.tutorialState == 2 else False
        self.fields["Victory"] = 1
        self.fields["Result"] = 0
        self.fields["Rank"] = 1
        self.fields["EventSlotThing"] = 1
        self.fields["Index"] = 0
        try:
            self.fields["Victory"] = self.readVInt()
            self.fields["Result"] = self.readVInt()
            self.fields["Rank"] = self.readVInt()
            self.fields["EventSlotThing"] = self.readVInt()
            self.fields["Index"] = self.readVInt()
        except Exception:
            pass
        self.fields["GameMode"] = self._resolve_game_mode()
        try:
            heroes_count = self.readVInt()
        except Exception:
            heroes_count = 0
        if not isinstance(heroes_count, int):
            heroes_count = 0
        self.fields["Heroes"] = []
        for i in range(max(0, min(heroes_count, 10))):
            try:
                brawler_ref = self.readDataReference()
                skin_ref = self.readDataReference()
                team = self.readVInt()
                is_player = self.readBoolean()
                player_name = self.readString()
            except Exception:
                break
            if not brawler_ref or len(brawler_ref) < 2:
                brawler_ref = [16, getattr(self.player, "brawler_id", 0) or 0]
            if player_name is None:
                player_name = self.player.name if is_player else ""
            self.fields["Heroes"].append({
                "Brawler": {"ID": [brawler_ref[0], brawler_ref[1]], "SkinID": skin_ref, "Trophies": 0, "PowerLevel": 1},
                "Team": team,
                "IsPlayer": bool(is_player),
                "PlayerName": player_name,
                "LowID": 0,
            })
        if not self.fields["Heroes"]:
            skin_id = getattr(self.player, "skin_id", 0)
            self.fields["Heroes"].append({
                "Brawler": {"ID": [16, getattr(self.player, "brawler_id", 0) or 0], "SkinID": [29, skin_id] if isinstance(skin_id, int) else None, "Trophies": 0, "PowerLevel": 1},
                "Team": 0,
                "IsPlayer": True,
                "PlayerName": self.player.name,
                "LowID": 0,
            })
        self.fields["HeroesCount"] = len(self.fields["Heroes"])
        local_index = 0
        for index, hero in enumerate(self.fields["Heroes"]):
            if hero.get("IsPlayer"):
                local_index = index
                break
        local_hero = self.fields["Heroes"][local_index]
        local_hero["LowID"] = self.player.low_id
        stats = self._local_brawler_stats(local_hero["Brawler"]["ID"][1])
        local_hero["Brawler"]["Trophies"] = stats.get("Trophies", 0)
        local_hero["Brawler"]["PowerLevel"] = stats.get("PowerLevel", 0) + (1 if stats.get("StarPower", 0) == 0 else 2)
        self.fields["receiveTime"] = time.time()
        self.fields["BattleEndKey"] = (
            self.fields["Victory"],
            self.fields["Result"],
            self.fields["Rank"],
            self.fields["EventSlotThing"],
            self.fields["Index"],
            self.fields["GameMode"],
            tuple(
                (
                    hero["Brawler"]["ID"][0],
                    hero["Brawler"]["ID"][1],
                    tuple(hero["Brawler"]["SkinID"]) if hero["Brawler"]["SkinID"] else None,
                    hero["Team"],
                    hero["IsPlayer"],
                    hero["PlayerName"],
                )
                for hero in self.fields["Heroes"]
            ),
        )

    def process(self, crypter):
        self.player.lastRecieved = self.fields["receiveTime"]
        cached_rewards = getattr(self.player, "lastBattleEndRewards", None)
        if cached_rewards is not None and getattr(self.player, "lastBattleEndKey", None) == self.fields.get("BattleEndKey") and time.time() - getattr(self.player, "lastBattleEndTime", 0) < 15:
            for hero in self.fields.get("Heroes", []):
                if hero.get("IsPlayer"):
                    hero["Brawler"]["Trophies"] = cached_rewards.get("brawler_trophies", hero["Brawler"]["Trophies"])
                    break
        BattleResultMessage(self.client, self.player, self.fields).send(crypter)
