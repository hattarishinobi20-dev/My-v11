from Packets.Messages.Server.Battle.MatchMakingStatusMessage import MatchMakingStatusMessage

from Packets.PiranhaMessage import PiranhaMessage


class OnPlay(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client


    def decode(self):

        self.fields["Brawler"] = self.readDataReference()

        self.fields["Unk"] = self.readVInt()
        self.fields["MapIndex"] = self.readVInt()
        self.fields["Unk1"] = self.readVInt()
        self.fields["Unk2"] = self.readVInt()
        self.fields["Unk3"] = self.readVInt()
        #super().decode(self.fields)
        #return self.fields

    def process(self, crypter):
        MatchMakingStatusMessage(self.client, self.player, self.fields).send(crypter)
