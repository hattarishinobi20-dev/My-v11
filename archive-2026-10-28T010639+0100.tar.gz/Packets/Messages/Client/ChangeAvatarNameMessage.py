from Packets.Commands.Server.LogicChangeAvatarNameCommand import LogicChangeAvatarNameCommand
from Packets.Messages.Server.Home.AvatarNameChangeFailedMessage import AvatarNameChangeFailedMessage

from Packets.PiranhaMessage import PiranhaMessage

class ChangeAvatarNameMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.username = self.readString()
        try:
            self.state = self.readVInt()
        except Exception:
            self.state = 0

    def process(self, crypter):
        if self.username != '':
            if len(self.username) >= 2 and len(self.username) <= 20:
                self.player.name = self.username
                LogicChangeAvatarNameCommand(self.client, self.player, self.state).send(crypter)
            else:
                AvatarNameChangeFailedMessage(self.client, self.player).send(crypter)
        else:
            AvatarNameChangeFailedMessage(self.client, self.player).send(crypter)
