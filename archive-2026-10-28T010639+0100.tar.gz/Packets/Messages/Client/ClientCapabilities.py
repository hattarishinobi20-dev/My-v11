from random import choice
from string import ascii_uppercase
import json
from Database.DatabaseManager import DataBase
from Logic.Player import Players

from Packets.PiranhaMessage import PiranhaMessage


class ClientCapabilities(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.ping = self.readVInt()

    def process(self, crypter):
        pass