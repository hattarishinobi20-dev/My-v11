from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage

from Packets.Messages.Server.Friend.Events.AddFriendFailedMessage import AddFriendFailedMessage
from Packets.Messages.Server.Friend.FriendListUpdateMessage import FriendListUpdateMessage


class AddFriend(PiranhaMessage):

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.HighID = 0
        self.LowID = 0
        try:
            self.HighID = self.readInt()
            self.LowID = self.readInt()
        except Exception:
            pass

    def process(self, crypter):
        db = DataBase(self.player)
        if not isinstance(self.player.friends, dict):
            self.player.friends = {}
        newFriend = db.getTokenByLowId(self.LowID)
        if not newFriend or newFriend == self.player.token or self.LowID == self.player.low_id:
            AddFriendFailedMessage(self.client, self.player).send(crypter)
            return
        players = db.getSpecifiedPlayers([newFriend])
        if not players:
            AddFriendFailedMessage(self.client, self.player).send(crypter)
            return
        target_friends = players[0].get("friends")
        if not isinstance(target_friends, dict):
            target_friends = {}
        own_state = self.player.friends.get(newFriend)
        target_state = target_friends.get(self.player.token)
        if own_state == 3 or target_state == 2 or own_state == 0 or target_state == 0:
            self.player.friends[newFriend] = 0
            target_friends[self.player.token] = 0
        else:
            self.player.friends[newFriend] = 2
            target_friends[self.player.token] = 3
        db.replaceValue("friends", self.player.friends)
        db.replaceOtherValue("friends", target_friends, newFriend)
        FriendListUpdateMessage(self.client, self.player, self.LowID, players).send(crypter)
