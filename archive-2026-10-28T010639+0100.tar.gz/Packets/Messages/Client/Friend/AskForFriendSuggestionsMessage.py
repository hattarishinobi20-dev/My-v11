from Packets.Messages.Server.Friend.AddableFriendsMessage import AddableFriendsMessage
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage
class AskForFriendSuggestionsMessage(PiranhaMessage):

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self, crypter):
        def by_trophy(plr):
                return plr['trophies']
        
        db = DataBase(self.player)
                
        players = []
        AddableFriendsMessage(self.client, self.player, players).send(crypter)