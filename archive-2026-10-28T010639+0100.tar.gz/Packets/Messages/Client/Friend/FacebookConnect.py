from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Friend.Events.FacebookBindOKMessage import FacebookBindOKMessage
from Packets.Messages.Server.Friend.Events.FBAccountDisconnectedOKMessage import FBAccountDisconnectedOKMessage

from Packets.PiranhaMessage import PiranhaMessage

class FacebookConnect(PiranhaMessage):

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        try:
            self.readVInt()
            self.player.FacebookID = self.readString()
            self.player.FacebookToken = self.readString()
        except Exception:
            if getattr(self.player, "FacebookID", None) is None:
                self.player.FacebookID = "None"
            if getattr(self.player, "FacebookToken", None) is None:
                self.player.FacebookToken = "None"

    def process(self, crypter):
        self.player.IsFacebookLinked = 1
        self.player.is_fb_linked = 1
        self.player.facebook_id = self.player.FacebookID
        db = DataBase(self.player)
        db.replaceValue('is_fb_linked', 1)
        db.replaceValue('facebook_id', self.player.FacebookID)

        FacebookBindOKMessage(self.client, self.player).send(crypter)
