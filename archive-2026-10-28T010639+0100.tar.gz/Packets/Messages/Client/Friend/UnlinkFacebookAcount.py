from Packets.Messages.Server.Friend.Events.FBAccountDisconnectedOKMessage import FBAccountDisconnectedOKMessage
from Database.DatabaseManager import DataBase

from Packets.PiranhaMessage import PiranhaMessage

class UnlinkFacebookAcount(PiranhaMessage):

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        try:
            self.readVInt()
            self.player.FacebookID = self.readString()
            self.player.FacebookToken = self.readString()
        except Exception:
            pass

    def process(self, crypter):
        self.player.IsFacebookLinked = 0
        self.player.is_fb_linked = 0
        self.player.FacebookID = "None"
        self.player.FacebookToken = "None"
        self.player.facebook_id = "None"
        db = DataBase(self.player)
        db.replaceValue('is_fb_linked', 0)
        db.replaceValue('facebook_id', "None")

        FBAccountDisconnectedOKMessage(self.client, self.player).send(crypter)
