from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Gameroom.TeamStreamMessage import TeamStreamMessage
from Logic.Player import Players
from Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Gameroom.TeamErrorMessage import TeamErrorMessage

class TeamSpectateMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client


    def decode(self):
        self.fields = {}
        self.fields["Unk1"] = self.readVInt()
        self.fields["Unk2"] = self.readVInt()
        self.fields["Unk3"] = self.readVInt()

    def process(self, crypter):
        db = DataBase(self.player)
        if self.player.room_id != 0:
            if db.loadGameroom():
                TeamGameroomDataMessage(self.client, self.player).send(crypter)
                return
            self.player.room_id = 0
        joined = db.joinGameroom(self.fields["Unk2"])
        if joined:
            db.connection.commit()
            self.player.room_id = self.fields["Unk2"]
            db.replaceValue('room_id', self.player.room_id)
            db.addGameroomMsg(self.player.room_id, 4, self.player.low_id, self.player.name, " ", 102, self.player.low_id, self.player.name)
            self.player.lastSeenGameroomKey = db.getNextGameroomKey(self.player.room_id)
            TeamGameroomDataMessage(self.client, self.player).send(crypter)
            TeamStreamMessage(self.client, self.player, self.player.room_id).send(crypter)
        else:
            TeamErrorMessage(self.client, self.player, 6).send(crypter)
