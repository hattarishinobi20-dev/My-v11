from Packets.Messages.Server.Home.PlayerProfileMessage import PlayerProfileMessage
from Database.DatabaseManager import DataBase
from random import choice
from string import ascii_uppercase
import json
from Packets.PiranhaMessage import PiranhaMessage


class AskProfileMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.highID = self.readInt()
        self.lowID = self.readInt()


    def process(self, crypter):
        db = DataBase(self.player)
        self.players = db.getAllPlayers()
        if any(player.get("low_id") == self.lowID for player in self.players):
            PlayerProfileMessage(self.client, self.player, self.highID, self.lowID, self.players).send(crypter)