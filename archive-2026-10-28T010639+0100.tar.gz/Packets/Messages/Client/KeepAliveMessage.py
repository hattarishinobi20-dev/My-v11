from random import choice
from string import ascii_uppercase
import json
from Logic.Player import Players
from Logic import OnlineTracker
from Packets.Messages.Server.KeepAliveOkMessage import KeepAliveOkMessage
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Messages.Server.Battle.MatchMakingStatusMessage import MatchMakingStatusMessage
from Logic.LogicBattle import LogicBattle
import time
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage
from Packets.Messages.Server.Friend.FriendOnlineStatusEntryMessage import FriendOnlineStatusEntryMessage
from Packets.Commands.Server.LogicDayChanged import LogicDayChanged
from Packets.Messages.Server.Gameroom.TeamChatServerMessage import TeamChatServerMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Alliance.AllianceTeamsMessage import AllianceTeamsMessage

class KeepAliveMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self, crypter):
        OnlineTracker.touch(self.player.low_id)
        KeepAliveOkMessage(self.client, self.player).send(crypter)
        db = DataBase(self.player)
        offers = db.load_offers(self.player.token)
        if not offers:
            db.initialize_player_offers(self.player.token)
            offers = db.load_offers(self.player.token)
        offfers = offers.get("info", {}) if offers else {}
        for index in range(len(offfers)):
            if offers["info"][str(index)]["Timer"] < time.time():
                db.reroll_offer(self.player.token, index)
        #eventData = db.loadEvents(1)

        #event = eventData["info"]["events"][str(0)]
        #if self.player.lastEventTimeStamp != event["TimeStamp"]:
            #LogicDayChanged(self.client, self.player, False, True)
            
        #LogicDayChanged(self.client, self.player, True, True)
        
        db.loadAccount()
        if not self.player.settings.get("EnableSocialPackets", True):
            return
        def by_trophy(plr):
                return plr['trophies']
        tokens = []
        for token in self.player.friends:
            tokens.append(token)
        players = db.getSpecifiedPlayers(tokens)
        players.sort(key = by_trophy, reverse=True)
        for player in players:
                FriendOnlineStatusEntryMessage(self.client, self.player, player["low_id"]).send(crypter)
        if self.player.room_id != 0:
            try:
                if db.loadGameroom():
                    TeamGameroomDataMessage(self.client, self.player).send(crypter)
                    nextKey = db.getNextGameroomKey(self.player.room_id)
                    if self.player.lastSeenGameroomKey > nextKey:
                        self.player.lastSeenGameroomKey = nextKey
                    while self.player.lastSeenGameroomKey < nextKey:
                        TeamChatServerMessage(self.client, self.player, self.player.room_id, self.player.lastSeenGameroomKey+2).send(crypter)
                        self.player.lastSeenGameroomKey+=1
                    self.player.lastSeenGameroomKey = nextKey
                else:
                    self.player.room_id = 0
            except Exception:
                pass
        if self.player.club_id != 0:
            MyAllianceMessage(self.client, self.player, self.player.club_id).send(crypter)
            AllianceDataMessage(self.client, self.player, 0, self.player.club_id).send(crypter)
            nextKey = db.getNextKey(self.player.club_id)
            if self.player.lastSeenKey > nextKey:
                self.player.lastSeenKey = nextKey
            while self.player.lastSeenKey < nextKey:
                AllianceChatServerMessage(self.client, self.player, self.player.club_id, self.player.lastSeenKey+2).send(crypter)
                self.player.lastSeenKey+=1
            clubMessages = db.loadClubMessages(self.player.club_id)
            joinRequests = []
            if clubMessages != None:
              for messageKey in sorted(clubMessages["info"]["messages"].keys(), key=lambda k: int(k) if str(k).isdigit() else 0):
                  clubMessage = clubMessages["info"]["messages"][messageKey]
                  if clubMessage.get("EventType") == 3:
                      joinRequests.append(clubMessage["Tick"])
            for message in joinRequests:
                AllianceChatServerMessage(self.client, self.player, self.player.club_id, message+1).send(crypter)
#            AllianceTeamsMessage(self.client, self.player).send(crypter)
            
            
        else:
            MyAllianceMessage(self.client, self.player, 0).send(crypter)
        
        
        FriendListMessage(self.client, self.player, players).send(crypter)
        for player in players:
                FriendOnlineStatusEntryMessage(self.client, self.player, player["low_id"]).send(crypter)
            
            #self.player.lastSeenKey = nextKey
        player_count = 2
        if self.player.matchmakeState == 1:
            try:
                self.fields["MapIndex"] = self.player.MapIndex
                db.loadMMPool(self, self.player.MapIndex)
                
                if self.playercount - player_count == 9:
                    MatchMakingStatusMessage(self.client, self.player, self.fields).send()
                elif self.playercount == self.playercount:
                    MatchMakingStatusMessage(self.client, self.player, self.fields).send()
                    time.sleep(0.5)
                    for key, x in self.matchmakedata.items():
                        if self.player.token == key:
                            self.player.playermmindex = x
                    battle = LogicBattle(self.client, self.player, self.device)
                    battle.start()
            except Exception as e:
                print(e)