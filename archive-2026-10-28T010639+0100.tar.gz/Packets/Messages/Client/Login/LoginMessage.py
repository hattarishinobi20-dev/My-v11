from Packets.Messages.Server.Login.LoginOkMessage import LoginOkMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage
from Packets.Messages.Server.UnknownServerPackets import UnknownServerPackets
from random import choice
from string import ascii_uppercase
import json
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.PiranhaMessage import PiranhaMessage
from Utils.Helpers import Helpers
from Utils.BanList import check_and_sync_ban
from Database.DatabaseManager import DataBase
from OgSaver.store import OgSaverStore
from Packets.Messages.Server.Friend.FriendOnlineStatusEntryMessage import FriendOnlineStatusEntryMessage
from Packets.Messages.Server.Alliance.AllianceTeamsMessage import AllianceTeamsMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Gameroom.TeamStreamMessage import TeamStreamMessage
import time

def _maintenance_status(player):
    enabled = bool(getattr(player, "maintenance", False))
    maintenance_time = getattr(player, "maintenance_time", 3600)
    try:
        with open('config.json', 'r') as config_file:
            settings = json.load(config_file)
        enabled = bool(settings.get("Maintenance", enabled))
        try:
            maintenance_time = int(settings.get("MaintenanceTime", maintenance_time))
        except (TypeError, ValueError):
            pass
    except Exception:
        pass
    return enabled, maintenance_time

def _send_ban_if_needed(client, player, crypter):
    try:
        reason = check_and_sync_ban(player.low_id, getattr(player, "last_ip", ""))
    except Exception:
        return False
    if reason is None:
        return False
    player.err_code = 11
    LoginFailedMessage(client, player, "Your account has been banned", 11).send(crypter)
    player._close_after_packet = True
    return True

class LoginMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.player.high_id = self.readInt()
        self.player.low_id = self.readInt()
        self.player.token = self.readString()

        self.major = 0
        self.minor = 0
        self.build = 0
        self.fingerprint_sha = ""
        try:
            self.major = self.readInt()
            self.minor = self.readInt()
            self.build = self.readInt()

            self.fingerprint_sha = self.readString()

            Unk1 = self.readString()
            self.player.deviceID = self.readString()
            Unk2 = self.readString()
            self.player.Device = self.readString()
            self.player.preferredLanguage = self.readDataReference()
            region = self.readString()
            self.player.region = region.split('-')[1] if region and '-' in region else "US"
        except Exception:
            pass
        #print(self.player.region)

    def _handle_ogsaver(self, db, crypter):
        store = OgSaverStore()
        source_ip = str(getattr(self.player, "last_ip", "") or "")
        device_id = str(getattr(self.player, "deviceID", "") or "")
        incoming_token = str(getattr(self.player, "token", "") or "")
        try:
            incoming_low_id = int(getattr(self.player, "low_id", 0) or 0)
        except Exception:
            incoming_low_id = 0
        self.player.ogsaver_source_account_token = incoming_token
        self.player.ogsaver_source_low_id = incoming_low_id
        armed_id = None
        try:
            armed = store.claim_armed_redeem(source_ip, device_id, incoming_token, incoming_low_id)
            if armed:
                armed_id = int(armed["id"])
                target = store.get_game_player(armed.get("target_account_token"))
                if target is None:
                    store.fail_pending(armed_id, "The saved game account no longer exists on the server.")
                    armed_id = None
                else:
                    target_data = target["data"]
                    self.player.high_id = 0
                    self.player.low_id = int(target_data.get("low_id") or armed.get("target_low_id") or 0)
                    self.player.token = target["token"]
                    store.complete_redeem(armed_id, source_ip, incoming_token, incoming_low_id)
                    armed_id = None
                    print(f"[OgSaver] Account #{self.player.low_id} redeemed for Telegram user {armed.get('telegram_user_id')}")
                    return False
            alias = store.resolve_login_alias(incoming_token, incoming_low_id)
            if alias:
                target = store.get_game_player(alias.get("target_account_token"))
                if target is not None:
                    target_data = target["data"]
                    self.player.high_id = 0
                    self.player.low_id = int(target_data.get("low_id") or alias.get("target_low_id") or 0)
                    self.player.token = target["token"]
                    print(f"[OgSaver] Account #{self.player.low_id} loaded from saved login state for Telegram user {alias.get('telegram_user_id')}")
            return False
        except Exception as error:
            try:
                if armed_id is not None:
                    store.release_armed(armed_id)
            except Exception:
                pass
            print(f"[OgSaver] Login operation failed: {error}")
            return False

    def process(self, crypter):
        print(f"[LOGIN] {getattr(self.player, 'last_ip', '?')} conta #{self.player.low_id} cliente v{self.major}.{self.minor}.{self.build}")
        db = DataBase(self.player)
        maintenance, maintenance_time = _maintenance_status(self.player)
        if maintenance:
            self.player.err_code = 10
            self.player.maintenance_time = maintenance_time
            LoginFailedMessage(self.client, self.player, "", 10).send(crypter)
            self.player._close_after_packet = True
            return
        if self.major not in (0, 11):
            print(f"[LOGIN] {getattr(self.player, 'last_ip', '?')} REJEITADO: cliente v{self.major} (servidor = v11) - APK incompativel")
            self.player.err_code = 16
            LoginFailedMessage(self.client, self.player, "", 16).send(crypter)
            self.player._close_after_packet = True
            return


        if _send_ban_if_needed(self.client, self.player, crypter):
            return
        if not (self.fingerprint_sha != self.player.patch_sha and self.player.patch) and self._handle_ogsaver(db, crypter):
            return
        if self.fingerprint_sha != self.player.patch_sha and self.player.patch:
            LoginFailedMessage(self.client, self.player, "", self.player.err_code).send(crypter)
            self.player._close_after_packet = True

        elif self.player.low_id != 0:
            db.cursor.execute("SELECT COUNT(*) FROM Players WHERE token = ?", (self.player.token,))
            if db.cursor.fetchone()[0] == 0:
                db.getPlayerId()
                db.createAccount()
            db.loadAccount()
            if _send_ban_if_needed(self.client, self.player, crypter):
                return
            LoginOkMessage(self.client, self.player).send(crypter)
            offers = db.load_offers(self.player.token)
            if not offers:
                db.initialize_player_offers(self.player.token)
                offers = db.load_offers(self.player.token)
            offfers = offers["info"]
            for index in range(len(offfers)):
                if offers["info"][str(index)]["Timer"] < time.time():
                    db.reroll_offer(self.player.token, index)
            OwnHomeDataMessage(self.client, self.player).send(crypter)
            try:
                room_info = db.loadGameroom() or {}
            except Exception:
                room_info = {}
            if not room_info:
                self.player.room_id = 0
            if not self.player.settings.get("EnableSocialPackets", True):
                return
            
            MyAllianceMessage(self.client, self.player, self.player.club_id).send(crypter)
            def by_trophy(plr):
                return plr['trophies']
            db = DataBase(self.player)
            tokens = []
            for token in self.player.friends:
                tokens.append(token)
            players = db.getSpecifiedPlayers(tokens)
            players.sort(key = by_trophy, reverse=True)
            FriendListMessage(self.client, self.player, players).send(crypter)
            for player in players:
                FriendOnlineStatusEntryMessage(self.client, self.player, player["low_id"]).send(crypter)
            nextKey = db.getNextKey(self.player.club_id)
            self.player.lastSeenKey = nextKey
            AllianceStreamMessage(self.client, self.player, self.player.club_id, 0).send(crypter)
#            AllianceTeamsMessage(self.client, self.player).send(crypter)
            if self.player.room_id > 0 and room_info:
                try:
                    self.player.lastSeenGameroomKey = db.getNextGameroomKey(self.player.room_id)
                    TeamGameroomDataMessage(self.client, self.player).send(crypter)
                    TeamStreamMessage(self.client, self.player, self.player.room_id).send(crypter)
                except Exception:
                    pass
            

            
        else:
            
            #self.player.low_id = Helpers.randomID(self)
            self.player.high_id = 0
            self.player.token = Helpers.randomStringDigits(self)
            db.getPlayerId()
            db.createAccount()
            if _send_ban_if_needed(self.client, self.player, crypter):
                return
            LoginOkMessage(self.client, self.player).send(crypter)
            OwnHomeDataMessage(self.client, self.player).send(crypter)
            MyAllianceMessage(self.client, self.player, self.player.club_id).send(crypter)