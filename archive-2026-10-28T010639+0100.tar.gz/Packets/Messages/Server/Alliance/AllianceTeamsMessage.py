from Database.DatabaseManager import DataBase
from Utils.Writer import Writer
import json
from Entries.AllianceTeamEntry import AllianceTeamEntry

class AllianceTeamsMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24364
        self.player = player

    def encode(self):
        self.writeBoolean(True) # exists?
        self.writeVInt(2) # amount
        for x in range(2):
            AllianceTeamEntry.encode(self)