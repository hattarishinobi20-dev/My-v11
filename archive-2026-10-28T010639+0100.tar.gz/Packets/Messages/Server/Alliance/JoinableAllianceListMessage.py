import json
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Logic import OnlineTracker


class JoinableAllianceListMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24304
        self.player = player

    def encode(self):
        db = DataBase(self.player)
        clubs =  db.countClubs(1, 100, 2, 50)

        self.writeVint(len(clubs[0]))
        index = 0
        for i in clubs[1]:
            self.writeInt(0)                                 # ClubHighID
            self.writeInt(i["info"]["clubID"])                                 # ClubLowID
            self.writeString(i["info"]["name"])                  # Club name

            self.writeVint(8)                                # BadgeID type
            self.writeVint(i["info"]["clubBadge"])                 # Club badge number

            self.writeVint(i["info"]["clubType"])                    # Club type

            self.writeVint(len(i["info"]["memberCount"]))             # Member count

            self.writeVint(db.getClubTrophies(i["info"]["memberCount"]))                # Trophies total
            self.writeVint(i["info"]["requiredTrophies"])          # Trophies needed
            self.writeVint(0)                                # Region (null DataReference)
            self.writeVint(OnlineTracker.count_online([p.get("low_id", 0) for p in db.getSpecifiedPlayers(i["info"]["memberCount"])]))             # Members online
        index += 1