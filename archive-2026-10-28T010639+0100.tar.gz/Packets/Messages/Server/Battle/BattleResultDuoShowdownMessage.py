from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class BattleResultDuoShowdownMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23456
        self.player = player

    def encode(self):
        self.writeVint(5) # Battle Result Type
        self.writeVint(self.player.rank) # Rank Score


        self.writeVint(tokens) # Tokens Gained
        if self.player.result < 16:
            self.writeVint(0) # Trophies Result 
        if self.player.result >= 16:
            self.writeVint(trophiesinresult) # Trophies Result
        self.writeVint(doubledtokens) # Doubled Tokens
        self.writeVint(remainingtokens) # Token Doubler Remaining
        self.writeVint(0) # Unknown
        self.writeVint(result) # Battle Result Info and Stuff
        self.writeVint(2) # Battle End Screen Players
        
        self.writeString(self.player.name) # Your Name
        self.writeVint(1) # Self Star Player Type
        self.writeVint(16) # Player Brawler 
        self.writeVint(self.player.brawler_id)
        self.writeVint(29) # Player Skin 
        self.writeVint(self.player.skin_id)
        self.writeVint(brawler_trophies) # Your Brawler Trophies
        self.writeVint(10) # Your Brawler Power Level
        bool = True
        self.writeBoolean(bool)
        if bool == True:
            self.writeInt(0) # Your HighID
            self.writeInt(1) # Your LowID
        
        self.writeString('Bot 1') # Bot 1 Name
        self.writeVint(0) # Star Player Type
        self.writeVint(16) # Brawler CsvID
        self.writeVint(self.player.bot1) # Bot 1
        self.writeVint(0) # Skin CsvID
        self.writeVint(0) # Brawler Trophies
        self.writeVint(10) # Brawler Power Level
        bool = True
        self.writeBoolean(bool)
        if bool == True:
            self.writeInt(0) # HighID
            self.writeInt(2) # LowID
        

        # Experience Array
        self.writeVint(2) # Count
        self.writeVint(0) # Normal Experience ID
        self.writeVint(experience) # Normal Experience Ammount
        self.writeVint(8) # Star Player Experience ID
        self.writeVint(0) # Star Player Experience Ammount

        # Rank Up and Level Up Bonus Array
        self.writeVint(0) # Count


        # Trophies and Experience Bars Array
        self.writeVint(2) # Count
        self.writeVint(1) # Ranks Milestone ID
        self.writeVint(brawler_trophies) # Brawler Trophies Bar
        self.writeVint(brawler_trophies_for_rank) # Brawler Trophies for Rank
        self.writeVint(5) # Experience Milestone ID
        self.writeVint(self.player.player_experience -experience) # Total Experience Bar
        self.writeVint(self.player.player_experience -experience) # ???
        
        self.writeScId(26, self.player.profile_icon)  # Player Profile Icon (Unused since 2017)
        self.writeBoolean(True)  # Play Again

        
