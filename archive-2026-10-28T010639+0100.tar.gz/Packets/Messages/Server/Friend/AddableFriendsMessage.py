from Utils.Writer import Writer
from Database.DatabaseManager import DataBase

class AddableFriendsMessage(Writer):

    def __init__(self, client, player, players):
        super().__init__(client)
        self.id = 20199
        self.player = player
        self.players = players

    def encode(self):
        self.indexOfPlayer = 1
        db = DataBase(self.player)
        self.writeInt(len(self.players)) # Player Count
        for player in self.players:
            if player["low_id"] == self.player.low_id:
                self.indexOfPlayer = self.players.index(player) + 1
        
            self.writeInt(0) # Games Played Together Recently

            self.writeInt(0)  # HighID
            self.writeInt(player["low_id"])  # LowID

            self.writeString(player['name'])
            self.writeString()
            self.writeString()
            self.writeString()


            self.writeInt(28)  # Trophies
            self.writeInt(player['trophies'])  # Friend state 0 = friend, 1 = not friend, 2 = request sent, 3 = you have an invite from him??, 4 = friend list
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
        
            if player["club_id"] != 0:
                club = db.loadClub(player["club_id"])

                self.writeBoolean(True)  # Is in club
           
                self.writeInt(0)
                self.writeInt(0)
                self.writeInt(0)
                self.writeString(club["info"]["name"])
                self.writeInt(0)
                self.writeInt(0)    
            else:
                self.writeBoolean(False)  # Is in club
            
            self.writeString()
        
            self.writeInt(28000000 + player["profile_icon"])
            self.writeInt(0)