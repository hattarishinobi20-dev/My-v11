from Utils.Writer import Writer
from Entries.FriendOnlineStatusEntry import FriendOnlineStatusEntry
from Database.DatabaseManager import DataBase

class FriendOnlineStatusEntryMessage(Writer):

    def __init__(self, client, player, lowID):
        super().__init__(client)
        self.id = 24555
        self.player = player 
        self.lowID = lowID
    def encode(self):
        db = DataBase(self.player)
        playerToken = db.getTokenByLowId(self.lowID)
        playersData = db.getSpecifiedPlayers([playerToken])
        playerData = playersData[0]
        self.writeLong(0, self.lowID)#player id
        self.writeBoolean(True) # why sc
        FriendOnlineStatusEntry.encode(self, self.lowID, playerData)