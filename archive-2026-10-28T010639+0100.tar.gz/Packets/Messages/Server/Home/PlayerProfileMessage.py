from os import truncate
from Utils.Writer2 import Writer
from Database.DatabaseManager import DataBase


class PlayerProfileMessage(Writer):

    def __init__(self, client, player, high_id, low_id, players):
        super().__init__(client)
        self.id = 24113
        self.player = player
        self.high_id = high_id
        self.low_id = low_id
        self.players = players

    def encode(self):
        db = DataBase(self.player)
        for player in self.players:
            if self.low_id == player["low_id"]:
                

                self.writeVInt(self.high_id)  # High Id
                self.writeVInt(self.low_id)  # Low Id
                self.writeString(player["name"])
                self.writeVInt(0)  # Unknown

                self.writeVInt(len(player["unlocked_brawlers"]))  # Brawlers array

                for key, brawler_id in player["unlocked_brawlers"].items():
                    self.writeDataReference(16, int(key))
                    self.writeVInt(0)
                    self.writeVInt(brawler_id["Trophies"])  # Trophies 
                    self.writeVInt(brawler_id["HighestTrophies"])  # Trophies for rank
                    if brawler_id["PowerLevel"] == 8:
                        self.writeVInt(10)  # power lvl
                    else:
                        self.writeVInt(1 + brawler_id["PowerLevel"])

                self.writeVInt(10)

                self.writeVInt(1)
                self.writeVInt(player["three_vs_three_wins"])  # 3v3 victories

                self.writeVInt(2)
                self.writeVInt(player["player_experience"]) # Player experience

                self.writeVInt(3)
                self.writeVInt(player["trophies"]) # Trophies
                self.writeVInt(4)
                self.writeVInt(player["highest_trophies"])  # Highest trophies

                self.writeVInt(5)
                self.writeVInt(len(player["unlocked_brawlers"])) # Brawlers list
                
                self.writeVInt(7)
                self.writeVInt(28000000 + player["profile_icon"]) # Profile icon??

                self.writeVInt(8)
                self.writeVInt(player["solo_wins"])  # Solo victories

                self.writeVInt(9)
                self.writeVInt(0) # Best robo rumble time

                self.writeVInt(10)
                self.writeVInt(0) # Best time as big brawler

                self.writeVInt(11)
                self.writeVInt(player["duo_wins"])  # Duo victories
                
                club = db.loadClub(player["club_id"]) if player["club_id"] != 0 else None
                self.writeBoolean(club is not None)  # Is in club
                if club is not None:

                    self.writeInt(0)
                    self.writeInt(player["club_id"])
                    self.writeString(club["info"]["name"])  # club name
                    self.writeDataReference(8, club["info"]["clubBadge"])  # Club badgeID
                    self.writeVInt(club["info"]["clubType"])  # club type | 1 = Open, 2 = invite only, 3 = closed
                    self.writeVInt(len(club["info"]["memberCount"]))  # Current members count
                    self.writeVInt(db.getClubTrophies(club["info"]["memberCount"]))
                    self.writeVInt(club["info"]["requiredTrophies"])  # Trophy required
                    self.writeVInt(0)  # (Unknown)
                    self.writeVInt(0)  # (Unknown)
                self.writeDataReference(25, player["club_role"])