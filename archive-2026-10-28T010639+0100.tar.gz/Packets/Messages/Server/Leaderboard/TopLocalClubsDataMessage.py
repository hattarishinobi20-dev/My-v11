from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class GetLeaderboardClubLocalOkMessage(Writer):

    def __init__(self, client, player, type):
        super().__init__(client)
        self.id = 24403
        self.player = player
        self.type = type

    def encode(self):
        db = DataBase(self.player)
        self.indexOfClub = 0
        self.writeVint(2)
        self.writeVint(0) # SCID
        self.writeString(self.player.region) # Player Region

        clubs =  db.countClubs(1, 100, 2, 200)

        def by_trophy(club):
            print(club)
            return club["info"]["trophies"]

        self.writeVint(len(clubs[0]))
        clubs[1].sort(key = by_trophy, reverse=True)

        for club in clubs[1]:
            if club["info"]["clubID"] == self.player.club_id:
                self.indexOfClub = clubs[1].index(club) + 1
            db.loadClub(club["info"]["clubID"])
            self.writeVint(0) # Club High ID
            self.writeVint(club["info"]["clubID"]) # Club Low ID

            self.writeVint(1)
            self.writeVint(club["info"]["trophies"]) # Club Trophies
            self.writeVint(2)

            self.writeString(club["info"]["name"]) # Club Name
            self.writeVint(len(club["info"]["memberCount"])) # Club Members Count

            self.writeVint(8) # Club Badge
            self.writeVint(club["info"]["clubBadge"]) # Club Name Color


        self.writeVint(0)
        self.writeVint(self.indexOfClub) # Index of the club
        self.writeVint(0)
        self.writeVint(0)
        self.writeString(self.player.region)