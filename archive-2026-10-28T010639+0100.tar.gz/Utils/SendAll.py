import socket
import time


def send_all(sock, data, timeout=30.0):
    view = memoryview(data)
    total = 0
    deadline = time.monotonic() + timeout
    while total < len(view):
        try:
            sent = sock.send(view[total:])
        except (socket.timeout, TimeoutError, BlockingIOError):
            if time.monotonic() >= deadline:
                raise ConnectionError("Send timeout")
            continue
        if sent == 0:
            raise ConnectionError("Socket connection broken during send")
        total += sent
        deadline = time.monotonic() + timeout
