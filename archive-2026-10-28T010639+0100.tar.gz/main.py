import json
import logging
import socket
import sqlite3
import time
from threading import Thread, Event

from Logic.Device import Device
from Logic.Player import Players
from Packets.LogicMessageFactory import packets
from Core.Crypto import Crypto
from serverStates import serverStates
from Database.DatabaseManager import DataBase
from Utils.BanList import migrate_legacy_banned_ips

logging.basicConfig(filename="errors.log", level=logging.INFO, filemode="w")

def log_info(*args):
    print("[INFO]", *args)


def start_admin_bot():
    """Inicia o bot do Telegram em uma thread separada do servidor do jogo."""
    try:
        from AdminBot import bot as admin_bot
        admin_bot.main()
    except Exception:
        logging.exception("AdminBot encerrou com erro")



class Server(Thread):
    def __init__(self, ip: str, port: int, serverStates):
        super().__init__()
        self.server = socket.socket()
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.port = port
        self.ip = ip
        self.serverStates = serverStates
        self._stop_event = Event()

    def run(self):
        self.server.bind((self.ip, self.port))
        log_info(f"Server started! Ip: {self.ip}, Port: {self.port}")
        self.server.listen()

        while self.serverStates.running:
            try:
                self.server.settimeout(1)
                client, address = self.server.accept()
                log_info(f"New connection! Ip: {address[0]}")
                ClientThread(client, address, self.serverStates).start()
            except socket.timeout:
                continue
            except Exception as e:
                logging.error(f"Error accepting client: {e}")

    def stop(self):
        self.serverStates.running = False
        self.server.close()
        log_info("Server stopped.")


class ClientThread(Thread):
    def __init__(self, client, address, serverStates):
        super().__init__()
        self.client = client
        self.address = address
        self.device = Device(self.client)
        self.player = Players(self.device)
        self.player.last_ip = address[0]
        self.player._close_after_packet = False
        self.serverStates = serverStates
        self._stop_event = Event()
        self.serverStates.player = self.player

    def recvall(self, length: int):
        data = b""
        deadline = time.time() + 30
        while len(data) < length:
            try:
                s = self.client.recv(length - len(data))
            except socket.timeout:
                if time.time() > deadline:
                    raise ConnectionError("Receive Error!")
                continue
            if not s:
                raise ConnectionError("Receive Error!")
            data += s
        return data

    def run(self):
        crypter = Crypto()
        last_packet = time.time()
        last_event_check = 0
        stage = "conectado"
        db = DataBase(self.player)
        self.client.settimeout(1.0)
        header_buffer = b""

        try:
            while self.serverStates.running:
                try:
                    chunk = self.client.recv(7 - len(header_buffer))
                except socket.timeout:
                    chunk = None
                if chunk is not None:
                    if not chunk:
                        break
                    header_buffer += chunk

                if time.time() - last_event_check >= 30:
                    last_event_check = time.time()
                    try:
                        eventData = db.loadEvents(1)
                        event = eventData["info"]["events"][str(0)]
                        if event["TimeStamp"] < time.time():
                            db.rerollEvents()
                    except Exception:
                        pass

                if len(header_buffer) == 7:
                    header = header_buffer
                    header_buffer = b""
                    last_packet = time.time()
                    packet_id = int.from_bytes(header[:2], "big")
                    length = int.from_bytes(header[2:5], "big")

                    if length > 1000000:
                        log_info(f"Cliente {self.address[0]} incompativel: pacote {packet_id} com tamanho invalido {length}.")
                        break

                    data = self.recvall(length)
                    pdata = crypter.decrypt(packet_id, data)
                    if pdata is None:
                        log_info(f"Cliente {self.address[0]} incompativel: Login nao decifrado (APK/chave errada).")
                        break

                    if packet_id in packets:
                        try:
                            if packet_id == 10100:
                                message = packets[packet_id](self.client, self.player, pdata, self.serverStates)
                            else:
                                message = packets[packet_id](self.client, self.player, pdata)
                            message.decode()
                            message.process(crypter)
                            if packet_id == 10100:
                                stage = "hello"
                            elif packet_id == 10101:
                                stage = "login"
                            elif packet_id == 10108:
                                stage = "keepalive"
                            if getattr(self.player, "_close_after_packet", False):
                                break
                        except (ConnectionError, TimeoutError, BrokenPipeError, ConnectionResetError):
                            raise
                        except Exception:
                            logging.exception(f"Erro ao processar o pacote {packet_id} de {self.address[0]}")
                    else:
                        log_info(f"Packet not handled! Id: {packet_id}")

                if time.time() - last_packet > 60:
                    break

        except Exception as e:
            log_info(f"Error with client {self.address[0]}: {e}")
            logging.exception(f"Error with client {self.address[0]}")
        finally:
            log_info(f"Ip: {self.address[0]} disconnected! (etapa: {stage})")
            try:
                from Logic import OnlineTracker
                OnlineTracker.player_offline(self.player.low_id)
            except Exception:
                pass
            try:
                self.player.player_status = 0
                db.replaceValue("player_status", self.player.player_status)
                self.player.last_connection_time = time.time()
                db.replaceValue("last_connection_time", self.player.last_connection_time)
            except Exception:
                pass
            try:
                self.client.close()
            except Exception:
                pass



if __name__ == "__main__":
    states = serverStates()
    states.running = True
    try:
        with open("config.json", "r") as config_file:
            _settings = json.load(config_file)
    except Exception:
        _settings = {}
    states.maintenance = bool(_settings.get("Maintenance", False))
    try:
        states.maintenanceTime = int(_settings.get("MaintenanceTime", states.maintenanceTime))
    except (TypeError, ValueError):
        pass
    log_info(f"Modo manutenção: {'ON' if states.maintenance else 'OFF'}")
    try:
        _migrated_bans = migrate_legacy_banned_ips()
        if _migrated_bans:
            log_info(f"Bans antigos migrados para banned_ip.json: {_migrated_bans}")
    except Exception:
        logging.exception("Falha ao migrar bans antigos")

    admin_bot_thread = Thread(target=start_admin_bot, name="AdminBot", daemon=True)
    admin_bot_thread.start()
    log_info("AdminBot iniciado em thread separada.")


    try:
        _port = int(_settings.get("Port", 14071))
    except (TypeError, ValueError):
        _port = 14071
    server = Server("0.0.0.0", _port, states)
    server.start()
