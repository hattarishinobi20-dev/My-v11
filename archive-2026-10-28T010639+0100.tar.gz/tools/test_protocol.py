import sys, time
sys.path.insert(0, '.')

class FakeClient:
    def __init__(self): self.sent = b''
    def send(self, data): self.sent += data

from Logic.Player import Players
from Database.DatabaseManager import DataBase

class R:
    def __init__(self, buf): self.b = buf; self.i = 0
    def byte(self):
        v = self.b[self.i]; self.i += 1; return v
    def vint(self):
        result = 0; shift = 0
        while True:
            byte = self.byte()
            if shift == 0:
                seventh = (byte & 0x40) >> 6
                msb = (byte & 0x80) >> 7
                byte = ((byte << 1) & ~0x181) | (msb << 7) | seventh
            result |= (byte & 0x7f) << shift
            shift += 7
            if not (byte & 0x80): break
        return (result >> 1) ^ (-(result & 1))
    def integer(self):
        v = int.from_bytes(self.b[self.i:self.i+4], 'big', signed=True); self.i += 4; return v
    def string(self):
        n = self.integer()
        if n == -1: return None
        s = self.b[self.i:self.i+n].decode('utf-8', 'replace'); self.i += n; return s
    def ref(self):
        c = self.vint()
        return (c, self.vint()) if c != 0 else (0, None)
    def arrvint(self):
        return [self.vint() for _ in range(self.vint())]

def make_player():
    p = Players(object())
    p.high_id = 0
    p.token = "T" * 40
    db = DataBase(p)
    p.low_id = 1
    try: db.createAccount()
    except Exception: pass
    db.loadAccount()
    return p

player = make_player()
print("[setup] conta de teste ok | brawlers:", list(player.unlocked_brawlers.keys()))

from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
msg = OwnHomeDataMessage(FakeClient(), player); msg.encode(); buf = msg.buffer
print(f"\n[OwnHomeData] {len(buf)} bytes")
r = R(buf)
print(" ts:", r.vint(), "| clubTimeout:", r.vint(), "| trofeus:", r.vint(), r.vint(),
      "| x:", r.vint(), "| trophyRoad:", r.vint(), "| exp:", r.vint(), "| icone:", r.ref())
n1 = r.vint(); print(" playedModes:", [r.vint() for _ in range(n1)])
nsel = r.vint(); print(" skins selecionadas:", [r.ref() for _ in range(nsel)])
nunl = r.vint(); uskins = [r.ref() for _ in range(nunl)]; print(" skins desbloqueadas:", uskins)
assert all(s[1] is None or s[1] <= 49 for s in uskins)
print(" byte+6vint:", r.byte(), [r.vint() for _ in range(6)])
print(" byte/vint/byte:", r.byte(), r.vint(), r.byte())
print(" doubler/timer/byte:", r.vint(), r.vint(), r.byte())
print(" vint/byte/4vint/bool:", r.vint(), r.byte(), [r.vint() for _ in range(4)], r.byte())
noff = r.vint(); print(" ofertas:", noff)
for _ in range(noff):
    items = [(r.vint(), r.vint(), r.ref(), r.vint()) for _ in range(r.vint())]
    print("   ", items, "| moeda/preco/tempo/vista/115/bool:", r.vint(), r.vint(), r.vint(), r.vint(), r.vint(), r.byte())
ac = r.vint(); print(" arrayA:", [[r.vint() for _ in range(3)] for _ in range(ac)])
print(" tokens/neg/0/tickets/0:", [r.vint() for _ in range(5)])
print(" shopTs:", r.vint(), "| 100/15:", r.vint(), r.vint(), "| caixas:", [r.vint() for _ in range(4)],
      "| doubler:", r.vint(), r.vint(), "| cap/50/999900:", [r.vint() for _ in range(3)])
print(" guaranteed:", r.arrvint())
ns = r.vint(); print(" slots:", ns, [r.vint() for _ in range(ns)])
def read_events(label):
    c = r.vint(); print(f" {label}: {c}")
    for _ in range(c):
        ev = (r.vint(), r.vint(), r.vint(), r.vint(), r.vint(), r.ref(), r.vint(), r.string(), r.vint())
        assert ev[5][0] == 15 and ev[5][1] <= 48, f"mapa invalido p/ v11: {ev}"
        print("   ", ev)
read_events("eventos primarios"); read_events("eventos secundarios")
for _ in range(6): print(" arrayConf:", r.arrvint())
pre = r.vint(); assert pre == 2, pre
count = r.vint(); assert count == 621, count
from Logic.Milestones import Milestones
blob = bytes.fromhex(''.join(Milestones.hexa.split()))
got = r.b[r.i:r.i+len(blob)]; r.i += len(blob)
assert got == blob, "milestones divergem do hexa de referencia v11"
print(" milestones: bytes identicos ao hexa da referencia v11 OK")
print(" pos-milestones:", [r.vint() for _ in range(4)], "| Long:", r.integer(), r.integer(), "| notif:", r.vint())
print(" avatar ids:", [r.vint() for _ in range(6)], "| nome:", r.string(), "| nameSet:", r.byte(), "| str:", r.string())
print(" n de arrays (8):", r.vint())
def read_commodity(label):
    c = r.vint(); items = [(r.ref(), r.vint()) for _ in range(c)]
    print(f" {label} ({c}):", items); return items
a1 = read_commodity("unlocks+recursos")
assert all(ref[1] is None or ref[1] <= 104 for ref, _ in a1 if ref[0] == 23)
read_commodity("trofeus"); read_commodity("trofeusRank")
print(" array vazio:", r.vint())
read_commodity("powerPoints"); read_commodity("powerLevel"); read_commodity("powerLevel v11")
sp = read_commodity("starPowers (23,*)")
assert all(ref[0] == 23 and 76 <= ref[1] <= 104 for ref, _ in sp), sp
print(" gemas/gemas/exp/zeros/tutorial:", [r.vint() for _ in range(11)])
print(" timestamp final:", r.vint())
print(f"[OwnHomeData] parse {r.i}/{len(buf)} bytes ->", "OK" if r.i == len(buf) else "ERRO DE FORMATO!")
assert r.i == len(buf)

from Packets.Messages.Server.Login.LoginOkMessage import LoginOkMessage
m2 = LoginOkMessage(FakeClient(), player); m2.encode(); r = R(m2.buffer)
ids = [r.integer() for _ in range(4)]; tok = r.string(); r.string(); r.string()
ver = [r.integer() for _ in range(3)]; env = r.string(); [r.integer() for _ in range(3)]
r.string(); r.string(); r.string(); r.integer(); r.string(); r.string(); r.string()
r.integer(); r.string(); r.string(); r.string(); r.vint()
print(f"\n[LoginOk] ids={ids} versao={ver} env={env!r} fim={r.i}/{len(m2.buffer)}")
assert ver == [11, 112, 1] and r.i == len(m2.buffer)

from Packets.Messages.Server.Battle.BattleResultMessage import BattleResultMessage
from Utils.ByteStream import ByteStream
heroes = []
names = [player.name, "Bot 1", "Bot 2", "Bot 3", "Bot 4", "Bot 5"]
for i in range(6):
    heroes.append({"Brawler": {"ID": [16, i % 3], "SkinID": [29, 0],
                               "Trophies": 0 if i else player.unlocked_brawlers["0"]["Trophies"], "PowerLevel": 1},
                   "Team": 0 if i < 3 else 1, "IsPlayer": i == 0, "PlayerName": names[i],
                   "LowID": player.low_id if i == 0 else 0})
fields = {"GameMode": 0, "Victory": 0, "Rank": 0, "Result": 0, "HeroesCount": 6, "Heroes": heroes,
          "isInRealGame": True, "receiveTime": time.time()}
m3 = BattleResultMessage(FakeClient(), player, fields); m3.encode(); b3 = m3.buffer
s = ByteStream(b3)
def norm(v): return v - 2**32 if isinstance(v, int) and v >= 2**31 else v
print(f"\n[BattleResult] {len(b3)} bytes | tipo={norm(s.readVInt())} resultado={norm(s.readVInt())} "
      f"tokens={norm(s.readVInt())} trofeus={norm(s.readVInt())} dobrados={norm(s.readVInt())} resto={norm(s.readVInt())} zero={norm(s.readVInt())}")
print(" booleans header (bit-pack):", [s.readBoolean() for _ in range(6)])
pc = s.readVInt(); print(" jogadores:", pc)
for _ in range(pc):
    nm = s.readString(); pb = [s.readBoolean() for _ in range(3)]
    br = s.readDataReference(); sk = s.readDataReference()
    tr = norm(s.readVInt()); pw = norm(s.readVInt()); ispl = s.readBoolean()
    lid = (s.readInt(), s.readInt()) if ispl else None
    print(f"   {nm} bools={pb} brawler={br} skin={sk} trofeus={tr} power={pw} isPlayer={ispl} id={lid}")
ec = s.readVInt(); print(" exp:", [(norm(s.readVInt()), norm(s.readVInt())) for _ in range(ec)])
print(" bonus:", s.readVInt())
bc = s.readVInt(); print(" barras:", bc, [norm(s.readVInt()) for _ in range(6)])
print(" milestones bool:", s.readBoolean(), "| count:", s.readVInt())
start = s.offset; raw = s.messagePayload[start:start+len(blob)]
assert raw == blob; s.offset = start + len(blob); s.bitoffset = 0
print(" dataref final:", s.readDataReference(), "| playAgain:", s.readBoolean(), f"| fim={s.offset}/{len(b3)}")
assert s.offset == len(b3)

print("\n[TODOS OS TESTES DE FORMATO PASSARAM]")
